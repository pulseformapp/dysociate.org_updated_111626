"""Exercise native Win32 submission, retry, and cancellation.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""

import ctypes
from ctypes import wintypes
from pathlib import Path
import sys
from threading import Thread
import time


def check(dll):
    user = ctypes.windll.user32
    user.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    user.FindWindowW.restype = wintypes.HWND
    user.GetDlgItem.argtypes = [wintypes.HWND, ctypes.c_int]
    user.GetDlgItem.restype = wintypes.HWND
    user.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    user.SendMessageW.restype = ctypes.c_ssize_t
    user.SetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPCWSTR]
    user.PostMessageW.argtypes = user.SendMessageW.argtypes
    user.IsWindowEnabled.argtypes = [wintypes.HWND]
    submit_type = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_int, wintypes.LPCWSTR, wintypes.LPCWSTR)
    poll_type = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.POINTER(ctypes.c_wchar), ctypes.c_int)
    compose = ctypes.CDLL(str(dll)).DysociateComposeThreadWithOptions
    compose.argtypes = [wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.LPCWSTR, submit_type, poll_type]
    compose.restype = ctypes.c_int
    drafts = []
    options = []
    polls = 0

    @submit_type
    def submit(action, title, body):
        nonlocal polls
        if action == 2:
            options.append((title, body))
            return 1
        drafts.append((title, body))
        polls = 0
        return 1

    @poll_type
    def poll(buffer, _capacity):
        nonlocal polls
        polls += 1
        if polls < 5:
            return 0
        if len(drafts) == 1:
            error = ctypes.create_unicode_buffer('Simulated temporary failure')
            ctypes.memmove(buffer, error, ctypes.sizeof(error))
            return -1
        return 1

    def drive(action):
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            window = user.FindWindowW('DysociateNativeComposer', None)
            if window and user.GetDlgItem(window, 1):
                # WM_SETTEXT is synchronous across threads. BM_CLICK dispatches
                # the same command that a mouse click sends to the parent.
                user.SetWindowTextW(user.GetDlgItem(window, 100), 'luna λ')
                user.SetWindowTextW(user.GetDlgItem(window, 101), 'One 🛰️\r\nTwo')
                button = user.GetDlgItem(window, action)
                user.PostMessageW(button, 0x00F5, 0, 0)
                if action == 1:
                    while time.monotonic() < deadline and user.IsWindowEnabled(button):
                        time.sleep(.01)
                    # While a request is pending, neither Close nor a queued
                    # activation may cancel or resubmit it.
                    user.PostMessageW(window, 0x0010, 0, 0)
                    user.PostMessageW(window, 0x0111, 1, 0)
                    while time.monotonic() < deadline and not user.IsWindowEnabled(button):
                        time.sleep(.01)
                    user.PostMessageW(button, 0x00F5, 0, 0)
                    time.sleep(.6)
                    user.PostMessageW(window, 0x0010, 0, 0)
                return
            time.sleep(.025)

    for action, expected_result in ((2, 0), (102, 2), (1, 1)):
        driver = Thread(target=drive, args=(action,), daemon=True)
        driver.start()
        assert compose(None, 'Pre-filled', 'Starting\r\ntext', 'Pilot', submit, poll) == expected_result
        driver.join(timeout=5)
        expected = [('luna λ', 'One 🛰️\r\nTwo')] * (2 if expected_result == 1 else 0)
        assert drafts == expected
    assert options == [('luna λ', 'One 🛰️\r\nTwo')]
    print('PASS Win32 Unicode input, More options, busy guard, failed submission, retry and Cancel')


if __name__ == '__main__':
    check(Path(sys.argv[1]).resolve(strict=True))
