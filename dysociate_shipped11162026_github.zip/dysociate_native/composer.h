/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
#pragma once

#include <array>
#include <cstdint>

namespace dysociate {

struct Rect {
    int x, y, width, height;
};

enum Field { Heading, TitleLabel, Title, BodyLabel, Body, Status, More, Cancel, Create, Copy, Share, FieldCount };
enum class Screen { Draft, Link, LinkWithShare };

struct Layout {
    std::array<Rect, FieldCount> fields;
    int height;
};

inline constexpr std::uint32_t field_color = 0xff190d23;
inline constexpr std::uint32_t text_color = 0xfffff1fa;
inline constexpr std::uint32_t accent_color = 0xffff76cf;
inline constexpr int max_width = 4096;
inline constexpr int max_height = 2560;

Layout layout(int width, float scale, Screen screen = Screen::Draft);
void paint(std::uint32_t* pixels, int width, int height, int stride, float scale, Screen screen = Screen::Draft);

}  // namespace dysociate
