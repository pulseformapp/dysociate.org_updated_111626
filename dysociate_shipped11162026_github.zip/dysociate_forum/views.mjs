/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later.
 */

import {lunaBlogTopicId, pageSize} from "./store.mjs";
import {publicForum, womenForum, womenForumTitle} from "./paths.mjs";

export const reasons = {
    hate: "Hate speech or harassment",
    threat: "Threat or private information",
    spam: "Spam",
    other: "Other",
};
export const answerLimit = 240;

const entities = {"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"};
function escape(value) {
    return String(value).replace(/[&<>"']/g, character => entities[character]);
}

export function html(title, body, status = 200, headers = {}) {
    return new Response(`<!doctype html>
<html lang="en">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#090512">
<title>${escape(title)} · dλsociate</title>
<link rel="icon" href="/assets/icon.png">
<link rel="stylesheet" href="/forum/style.css">
<body>
  <header class="top"><a href="/">{dλsociate}</a><a href="/forum">Public forum</a></header>
  <main>${body}</main>
</body>
</html>`, {status, headers: {"Content-Type": "text/html; charset=utf-8", ...headers}});
}

function pagination(path, page, count) {
    const join = path.includes("?") ? "&amp;" : "?";
    const previous = page > 0 ? `<a href="${path}${join}page=${page}">Previous page</a>` : "";
    const next = count > pageSize ? `<a href="${path}${join}page=${page + 2}">Next page</a>` : "";
    return previous || next ? `<nav class="pagination" aria-label="Pages">${previous}${next}</nav>` : "";
}

function submissionPath(topicId, forum = publicForum) {
    return topicId ? `${forum}/topic/${topicId}/reply` : forum;
}

function submitForm(topicId, forum) {
    return `<form method="post" action="${submissionPath(topicId, forum)}">
      ${topicId ? "" : '<label>Title<input name="title" maxlength="120" required></label>'}
      <label>${topicId ? "Reply" : "Post"}<textarea name="body" rows="5" maxlength="4000" required></textarea></label>
      <button type="submit">Submit for review</button>
    </form>`;
}

export function submissionQuestions({topicId, title, body}, answers = {}, invalid = false) {
    const value = name => escape((answers[name] || "").slice(0, answerLimit));
    return html("Submission questions", `<h1>Submission questions</h1>
      ${invalid ? '<p role="alert">Fill out all three answers using up to ' + answerLimit + ' characters each.</p>' : ""}
      <form class="panel" method="post" action="${submissionPath(topicId)}" autocomplete="off">
        <input type="hidden" name="step" value="questionnaire">
        ${title === null ? "" : `<input type="hidden" name="title" value="${escape(title)}">`}
        <textarea name="body" hidden>\n${escape(body)}</textarea>
        <label>What is your gender?<input name="gender" maxlength="${answerLimit}" value="${value("gender")}" required></label>
        <label>What is the topic of your post?<input name="topic" maxlength="${answerLimit}" value="${value("topic")}" required></label>
        <label><span>How did you hear about <strong>dλsociate</strong>?</span><input name="discovery" maxlength="${answerLimit}" value="${value("discovery")}" required></label>
        <p class="meta">{none of your responses on this form will disqualify your submission ~ this information is kept completely anonymous, and is only used to expedite the submission process.}</p>
        <button type="submit">Send submission</button>
      </form>`, invalid ? 400 : 200);
}

function reportForm(id, forum) {
    const options = Object.entries(reasons).map(([value, label]) => `<option value="${value}">${label}</option>`).join("");
    return `<details class="report"><summary>Report</summary>
      <form method="post" action="${forum}/report/${id}">
        <label>Reason<select name="reason" required><option value="">Choose a reason</option>${options}</select></label>
        <label>Details (optional)<textarea name="details" rows="3" maxlength="400"></textarea></label>
        <button type="submit">Send report</button>
      </form>
    </details>`;
}

function article(entry, forum) {
    return `<article id="post-${entry.id}">
      <p class="meta">Anonymous · <time datetime="${new Date(entry.published_at).toISOString()}">${new Date(entry.published_at).toISOString().slice(0,10)}</time></p>
      <p class="copy">${escape(entry.body)}</p>${entry.id === lunaBlogTopicId ? "" : reportForm(entry.id, forum)}
    </article>`;
}

export function forumIndex(entries, page, forum = publicForum) {
    const privateForum = forum === womenForum;
    const topics = entries.slice(0, pageSize).map(entry => {
        const preview = entry.id !== lunaBlogTopicId && entry.body.length > 220 ? entry.body.slice(0, 217) + "…" : entry.body;
        return `<article><h2><a href="${forum}/topic/${entry.id}">${escape(entry.title)}</a></h2><p class="copy">${escape(preview)}</p></article>`;
    }).join("");
    const heading = privateForum ? `<div class="row"><h1>${womenForumTitle}</h1>
      <form method="post" action="${forum}/leave"><button type="submit" class="secondary">Lock forum</button></form></div>
      <p>A private forum for women. Luna reviews each topic and reply before it appears. Other guests see posts as anonymous.</p>`
        : `<h1><a href="/">{dλsociate_forum}</a></h1>
      <p>Anyone can read and post. There is no account to create.  This forum is anonymous. A real human being reviews every topic &amp; reply before it appears. Hate speech, threats, harassment, and sharing someone else's private information WILL ABSOLUTELY NOT BE TOLERATED!</p>`;
    return html(privateForum ? womenForumTitle : "Public forum", `${heading}
      <details class="panel"><summary>New topic</summary>${submitForm(null, forum)}</details>
      <section class="feed" aria-label="Published topics">${topics || '<p class="meta">No published topics on this page.</p>'}</section>
      ${pagination(forum, page, entries.length)}`);
}

export function topicPage({root, replies}, page, forum = publicForum) {
    const path = `${forum}/topic/${root.id}`;
    const reply = root.id === lunaBlogTopicId ? "" : `<section class="panel"><h2>Reply</h2>${submitForm(root.id, forum)}</section>`;
    return html(root.title, `<a href="${forum}">← All topics</a><h1>${escape(root.title)}</h1>
      ${article(root, forum)}<section class="feed" aria-label="Published replies">${replies.slice(0,pageSize).map(entry => article(entry, forum)).join("")}</section>
      ${pagination(path, page, replies.length)}${reply}`);
}

export function receiptPage(receipt, forum = publicForum) {
    const messages = {
        pending: ["Pending review", "Your submission is saved. It will appear in the forum once a moderator approves it."],
        published: ["Published", "Your submission was approved."],
        declined: ["Submission declined", "A moderator declined this submission."],
        removed: ["Removed", "This submission is no longer available."],
    };
    const [title, copy] = messages[receipt.state];
    const link = receipt.topicId ? `<a href="${forum}/topic/${receipt.topicId}">View topic</a>` : `<a href="${forum}">Back to the forum</a>`;
    return html(title, `<h1>${title}</h1><p>${copy}</p>${link}`);
}

export function womenGate(next, failed = false, status = failed ? 401 : 200) {
    return html(womenForumTitle, `<h1>${womenForumTitle}</h1>
      <p>A private forum for women. Enter the invitation key Luna gave you directly.</p>
      ${failed ? '<p role="alert">This invitation key could not unlock the forum.</p>' : ""}
      <form class="panel" method="post" action="${womenForum}/unlock">
        <input type="hidden" name="next" value="${escape(next)}">
        <label>Invitation key<input type="password" name="key" maxlength="64" autocomplete="current-password" required></label>
        <button type="submit">Unlock forum</button>
      </form>`, status);
}

export function moderatorLogin(modPath, view, reportId, failed = false) {
    return html("Moderator sign-in", `<h1>Moderator sign-in</h1>
      ${failed ? '<p role="alert">Check the moderator key and try again.</p>' : ""}
      <form method="post" action="${modPath}/sign-in">
        <input type="hidden" name="view" value="${view}">
        ${reportId ? `<input type="hidden" name="report" value="${reportId}">` : ""}
        <label>Moderator key<input type="password" name="key" maxlength="128" autocomplete="current-password" required></label>
        <button type="submit">Sign in</button>
      </form>`, failed ? 401 : 200);
}

function decision(modPath, id, action, label, secondary = false, fromPublished = false) {
    return `<form method="post" action="${modPath}/decision${fromPublished ? '?view=published' : ''}">
      <input type="hidden" name="id" value="${id}"><input type="hidden" name="action" value="${action}">
      <button type="submit"${secondary ? ' class="secondary"' : ""}>${label}</button>
    </form>`;
}

function reviewCard(modPath, entry, view) {
    const reports = view === "reports";
    const heading = entry.title || `Reply to ${entry.topic_title}`;
    const hint = entry.hint ? `<p class="meta">Review hint · ${escape(entry.hint)}</p>` : "";
    const alert = entry.alert_sent_at ? "Email sent" : entry.alert_next === null ? "Email needs retry" : "Email queued";
    const report = reports ? `<p class="meta">${escape(reasons[entry.reason])} · ${entry.report_count} report(s) · ${alert}</p>
      ${entry.details ? `<p class="copy">${escape(entry.details)}</p>` : ""}` : "";
    const answers = entry.gender == null ? "" : `<details class="submission-answers"><summary>Submission answers</summary>
      <dl><dt>Gender</dt><dd>${escape(entry.gender)}</dd><dt>Post topic</dt><dd>${escape(entry.form_topic)}</dd>
        <dt>How they heard about dλsociate</dt><dd>${escape(entry.discovery)}</dd></dl></details>`;
    const invitation = entry.invite_id ? `<p class="meta">Invitation · ${inviteName(entry.invite_id, entry.invite_label)}</p>` : "";
    let controls = view === "pending"
        ? decision(modPath, entry.id, "approve", "Approve") + decision(modPath, entry.id, "decline", "Decline", true)
        : decision(modPath, entry.id, "remove", entry.topic_id ? "Remove reply" : "Remove topic and replies", true, view === "published");
    if (reports) {
        controls += decision(modPath, entry.report_id, "keep", "Keep published");
        if (entry.alert_next === null && !entry.alert_sent_at) controls += decision(modPath, entry.report_id, "retry", "Retry email", true);
    }
    return `<article${reports ? ` id="report-${entry.report_id}"` : ""}><h2>${escape(heading)}</h2>${invitation}${hint}${report}
      <p class="copy">${escape(entry.body)}</p>${answers}<div class="controls">${controls}</div></article>`;
}

function moderatorHeader(rootPath, view, women) {
    const modPath = women ? `${rootPath}/women` : rootPath;
    const sections = [
        ["pending", "Pending submissions", modPath],
        ["published", "Published", `${modPath}?view=published`],
        ["reports", "Reports", `${modPath}?view=reports`],
    ];
    if (women) sections.push(["invites", "Invitation keys", `${modPath}?view=invites`]);
    sections.push(["switch", women ? "Public forum moderation" : womenForumTitle, women ? rootPath : `${rootPath}/women`]);
    const tabs = sections.map(([id, label, path]) => `<a href="${path}"${view === id ? ' aria-current="page"' : ""}>${label}</a>`).join("\n");
    return `<div class="row"><h1>${women ? `${womenForumTitle} · Moderation` : "Moderation"}</h1>
      <form method="post" action="${modPath}/sign-out"><button class="secondary" type="submit">Sign out</button></form></div>
      <nav class="tabs" aria-label="Review queue">${tabs}</nav>`;
}

export function reviewPage(rootPath, entries, view, page, women = false) {
    const modPath = women ? `${rootPath}/women` : rootPath;
    const empty = {
        pending: "No submissions awaiting review on this page.",
        published: "No published topics or replies on this page.",
        reports: "No open reports on this page.",
    };
    const cards = entries.slice(0, pageSize).map(entry => reviewCard(modPath, entry, view)).join("");
    return html("Moderation", `${moderatorHeader(rootPath, view, women)}
      <section class="feed" aria-label="Review items">${cards || `<p class="meta">${empty[view]}</p>`}</section>
      ${pagination(`${modPath}?view=${view}`, page, entries.length)}
      <form method="post" action="${modPath}/test-email"><button class="secondary" type="submit">Send test alert</button></form>`);
}

function inviteName(id, label) {
    return `${escape(label || "Guest")} · ${id.slice(0, 8)}`;
}

export function invitePage(rootPath, entries, page) {
    const modPath = `${rootPath}/women`;
    const keys = entries.slice(0, pageSize).map(entry => `<article class="row">
      <div><h2>${inviteName(entry.id, entry.label)}</h2><p class="meta">${entry.revoked_at ? "Revoked" : "Active"} · Created ${new Date(entry.created_at).toISOString().slice(0, 10)}</p></div>
      ${entry.revoked_at ? "" : `<form method="post" action="${modPath}/revoke-invite">
        <input type="hidden" name="id" value="${entry.id}"><button type="submit" class="secondary">Revoke key</button>
      </form>`}</article>`).join("");
    return html("Invitation keys", `${moderatorHeader(rootPath, "invites", true)}
      <form class="panel" method="post" action="${modPath}/create-invite">
        <label>Label for your dashboard (optional)<input name="label" maxlength="80"></label>
        <button type="submit">Generate invitation key</button>
      </form>
      <section aria-label="Invitation keys">${keys || '<p class="meta">No invitation keys yet.</p>'}</section>
      ${pagination(`${modPath}?view=invites`, page, entries.length)}`);
}

export function inviteCreated(modPath, key) {
    return html("Invitation created", `<h1>Invitation created</h1>
      <p>Copy this key now and send it directly to the woman you’re inviting. Anyone with this key can enter the forum until you revoke it.</p>
      <div class="panel"><label>Invitation key<input value="${escape(key)}" readonly spellcheck="false"></label></div>
      <p>This is the only time the key is shown.</p>
      <a href="${modPath}?view=invites">Back to invitation keys</a>`, 201);
}

export function problem(message, status) {
    const title = status === 404 ? "Page unavailable" : "Forum notice";
    return html(title, `<h1>${title}</h1><p role="alert">${escape(message)}</p><a href="/forum">Back to the forum</a>`, status);
}
