/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later.
 */

import {DurableObject} from "cloudflare:workers";
import {deliverAlert} from "./alerts.mjs";
import {moderationPath, womenStoreName} from "./paths.mjs";

export const pageSize = 24;
export const lunaBlogTopicId = "eae8b4f3-66ea-4e0d-807c-ff8baf30f941";
const alertAttempts = 8;

export class ForumStore extends DurableObject {
    constructor(ctx, env) {
        super(ctx, env);
        this.storage = ctx.storage;
        this.sql = this.storage.sql;
        this.sql.exec(`
            CREATE TABLE IF NOT EXISTS entries (
                id TEXT PRIMARY KEY,
                topic_id TEXT REFERENCES entries(id),
                title TEXT,
                body TEXT NOT NULL,
                state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','published','declined','removed')),
                hint TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                published_at INTEGER,
                reviewed_at INTEGER
            );
            CREATE INDEX IF NOT EXISTS public_entries ON entries(topic_id, state, published_at, id);
            CREATE INDEX IF NOT EXISTS published_entries ON entries(published_at, id) WHERE state='published';
            CREATE INDEX IF NOT EXISTS review_entries ON entries(state, hint, created_at, id);
            CREATE TABLE IF NOT EXISTS submission_answers (
                entry_id TEXT PRIMARY KEY REFERENCES entries(id),
                gender TEXT NOT NULL,
                topic TEXT NOT NULL,
                discovery TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS invites (
                id TEXT PRIMARY KEY,
                digest TEXT NOT NULL UNIQUE,
                label TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                revoked_at INTEGER
            );
            CREATE TABLE IF NOT EXISTS submission_invites (
                entry_id TEXT PRIMARY KEY REFERENCES entries(id),
                invite_id TEXT NOT NULL REFERENCES invites(id)
            );
            CREATE TABLE IF NOT EXISTS reports (
                id TEXT PRIMARY KEY,
                entry_id TEXT NOT NULL REFERENCES entries(id),
                reason TEXT NOT NULL,
                details TEXT NOT NULL,
                report_count INTEGER NOT NULL DEFAULT 1,
                created_at INTEGER NOT NULL,
                reviewed_at INTEGER,
                alert_next INTEGER,
                alert_attempts INTEGER NOT NULL DEFAULT 0,
                alert_sent_at INTEGER
            );
            CREATE UNIQUE INDEX IF NOT EXISTS open_report ON reports(entry_id) WHERE reviewed_at IS NULL;
            CREATE INDEX IF NOT EXISTS review_reports ON reports(reviewed_at, created_at, id);
            CREATE INDEX IF NOT EXISTS outbox ON reports(alert_next) WHERE alert_sent_at IS NULL AND reviewed_at IS NULL;
        `);
        // Edit the stored blog once, immediately before its existing closing line.
        const closing = "Thank you for your submission!";
        const note = "Submissions that pass approval, will generally be posted within 24 hours.";
        this.sql.exec(`UPDATE entries SET body=substr(body,1,length(body)-length(?)) || ? || '  ' || ?
            WHERE id=? AND substr(body,-length(?))=? AND instr(body,?)=0`,
            closing, note, closing, lunaBlogTopicId, closing, closing, note);
    }

    row(query, ...args) {
        return this.sql.exec(query, ...args).toArray()[0] ?? null;
    }

    topics(page) {
        return this.sql.exec(`SELECT id,title,body,published_at FROM entries
            WHERE topic_id IS NULL AND state='published' ORDER BY published_at DESC,id DESC LIMIT ? OFFSET ?`,
            pageSize + 1, page * pageSize).toArray();
    }

    topic(id, page) {
        // A topic and its replies are read in the same turn. Every public read
        // requires a published root, including direct links to replies.
        const root = this.row(`SELECT id,title,body,published_at FROM entries
            WHERE id=? AND topic_id IS NULL AND state='published'`, id);
        if (!root) return null;
        const replies = this.sql.exec(`SELECT id,body,published_at FROM entries
            WHERE topic_id=? AND state='published' ORDER BY published_at,id LIMIT ? OFFSET ?`,
            id, pageSize + 1, page * pageSize).toArray();
        return {root, replies};
    }

    isPublishedTopic(id) {
        return Boolean(this.row("SELECT id FROM entries WHERE id=? AND topic_id IS NULL AND state='published'", id));
    }

    createInvite(digest, label) {
        this.sql.exec("INSERT INTO invites(id,digest,label,created_at) VALUES (?,?,?,?)",
            crypto.randomUUID(), digest, label, Date.now());
    }

    inviteForKey(digest) {
        return this.row("SELECT id FROM invites WHERE digest=? AND revoked_at IS NULL", digest)?.id ?? null;
    }

    activeInvite(id) {
        return Boolean(this.row("SELECT id FROM invites WHERE id=? AND revoked_at IS NULL", id));
    }

    invites(page) {
        return this.sql.exec(`SELECT id,label,created_at,revoked_at FROM invites
            ORDER BY (revoked_at IS NOT NULL),created_at DESC,id DESC LIMIT ? OFFSET ?`,
            pageSize + 1, page * pageSize).toArray();
    }

    revokeInvite(id) {
        this.sql.exec("UPDATE invites SET revoked_at=? WHERE id=? AND revoked_at IS NULL", Date.now(), id);
    }

    submit({topicId, title, body, hint, answers, inviteId}) {
        return this.storage.transactionSync(() => {
            // A key may be revoked while the request body is being read.
            if (inviteId && !this.activeInvite(inviteId)) return null;
            if (topicId && !this.isPublishedTopic(topicId)) return null;
            const id = crypto.randomUUID();
            this.sql.exec("INSERT INTO entries(id,topic_id,title,body,hint,created_at) VALUES (?,?,?,?,?,?)",
                id, topicId, title, body, hint, Date.now());
            // Save the private answers in the same transaction as the entry.
            // Public pages read entries only. The moderator queries join these answers.
            if (answers) this.sql.exec("INSERT INTO submission_answers(entry_id,gender,topic,discovery) VALUES (?,?,?,?)",
                id, answers.gender, answers.topic, answers.discovery);
            if (inviteId) this.sql.exec("INSERT INTO submission_invites(entry_id,invite_id) VALUES (?,?)", id, inviteId);
            return id;
        });
    }

    receipt(id) {
        const entry = this.row(`SELECT e.state,e.topic_id,p.state AS parent_state FROM entries e
            LEFT JOIN entries p ON p.id=e.topic_id WHERE e.id=?`, id);
        if (!entry) return null;
        if (entry.topic_id && entry.parent_state !== "published") return {state:"removed", topicId:null};
        return {state:entry.state, topicId:entry.state === "published" ? entry.topic_id || id : null};
    }

    async report(id, reason, details, inviteId) {
        const saved = this.storage.transactionSync(() => {
            if (inviteId && !this.activeInvite(inviteId)) return false;
            const post = this.row(`SELECT e.id FROM entries e LEFT JOIN entries p ON p.id=e.topic_id
                WHERE e.id=? AND e.state='published' AND (e.topic_id IS NULL OR p.state='published')`, id);
            if (!post) return false;
            // Keep one open case and one alert per post. Reports never alter
            // visibility. Only a moderator can do that from the review screen.
            const now = Date.now();
            this.sql.exec(`INSERT INTO reports(id,entry_id,reason,details,created_at,alert_next) VALUES (?,?,?,?,?,?)
                ON CONFLICT(entry_id) WHERE reviewed_at IS NULL DO UPDATE SET report_count=report_count+1`,
                crypto.randomUUID(), id, reason, details, now, now);
            return true;
        });
        if (saved) await this.scheduleAlert();
        return saved;
    }

    reviewQueue(view, page, reportId) {
        const inviteFields = `i.id AS invite_id,i.label AS invite_label`;
        const inviteJoin = `LEFT JOIN submission_invites si ON si.entry_id=e.id LEFT JOIN invites i ON i.id=si.invite_id`;
        if (view === "reports") return this.sql.exec(`SELECT r.id AS report_id,r.reason,r.details,r.report_count,
            r.alert_sent_at,r.alert_next,e.id,e.title,e.body,e.topic_id,p.title AS topic_title,
            a.gender,a.topic AS form_topic,a.discovery,${inviteFields}
            FROM reports r JOIN entries e ON e.id=r.entry_id LEFT JOIN entries p ON p.id=e.topic_id
            LEFT JOIN submission_answers a ON a.entry_id=e.id ${inviteJoin}
            WHERE r.reviewed_at IS NULL AND (? IS NULL OR r.id=?)
            ORDER BY r.created_at,r.id LIMIT ? OFFSET ?`, reportId, reportId, pageSize + 1, page * pageSize).toArray();
        if (view === "published") return this.sql.exec(`SELECT e.id,e.title,e.body,e.topic_id,p.title AS topic_title,
            a.gender,a.topic AS form_topic,a.discovery,${inviteFields}
            FROM entries e LEFT JOIN entries p ON p.id=e.topic_id
            LEFT JOIN submission_answers a ON a.entry_id=e.id ${inviteJoin}
            WHERE e.state='published' AND (e.topic_id IS NULL OR p.state='published')
            ORDER BY e.published_at DESC,e.id DESC LIMIT ? OFFSET ?`, pageSize + 1, page * pageSize).toArray();
        return this.sql.exec(`SELECT e.id,e.title,e.body,e.hint,e.topic_id,p.title AS topic_title,
            a.gender,a.topic AS form_topic,a.discovery,${inviteFields}
            FROM entries e LEFT JOIN entries p ON p.id=e.topic_id
            LEFT JOIN submission_answers a ON a.entry_id=e.id ${inviteJoin}
            WHERE e.state='pending' AND (e.topic_id IS NULL OR p.state='published')
            ORDER BY (e.hint='') ASC,e.created_at,e.id LIMIT ? OFFSET ?`, pageSize + 1, page * pageSize).toArray();
    }

    decide(action, id) {
        return this.storage.transactionSync(() => {
            const now = Date.now();
            if (action === "keep") return Boolean(this.row(`UPDATE reports SET reviewed_at=?
                WHERE id=? AND reviewed_at IS NULL RETURNING id`, now, id));
            if (action === "remove") {
                const entry = this.row(`UPDATE entries SET state='removed',reviewed_at=?
                    WHERE id=? AND state='published' RETURNING topic_id`, now, id);
                if (!entry) return false;
                // When a root is removed its replies disappear from public
                // queries as well. Close the cases for all affected entries.
                this.sql.exec(`UPDATE reports SET reviewed_at=? WHERE reviewed_at IS NULL AND
                    (entry_id=? OR ( ? IS NULL AND entry_id IN (SELECT id FROM entries WHERE topic_id=?)))`,
                    now, id, entry.topic_id, id);
                return true;
            }
            const publish = action === "approve";
            if (!publish && action !== "decline") return false;
            return Boolean(this.row(`UPDATE entries SET state=?,reviewed_at=?,published_at=?
                WHERE id=? AND state='pending' AND (topic_id IS NULL OR topic_id IN
                    (SELECT id FROM entries WHERE state='published' AND topic_id IS NULL)) RETURNING id`,
                publish ? "published" : "declined", now, publish ? now : null, id));
        });
    }

    async retryAlert(id) {
        const reset = this.row(`UPDATE reports SET alert_attempts=0,alert_next=? WHERE id=? AND
            reviewed_at IS NULL AND alert_sent_at IS NULL AND alert_next IS NULL RETURNING id`, Date.now(), id);
        if (reset) await this.scheduleAlert();
        return Boolean(reset);
    }

    async scheduleAlert() {
        const next = this.row(`SELECT MIN(alert_next) AS due FROM reports
            WHERE reviewed_at IS NULL AND alert_sent_at IS NULL`).due;
        if (next === null) return;
        const when = Math.max(next, Date.now() + 1000);
        const scheduled = await this.storage.getAlarm();
        if (scheduled === null || scheduled > when) await this.storage.setAlarm(when);
    }

    async sendAlert(subject, text) {
        await deliverAlert(this.env, subject, text);
    }

    async alarm() {
        const now = Date.now();
        const due = this.sql.exec(`SELECT id,alert_attempts FROM reports WHERE reviewed_at IS NULL
            AND alert_sent_at IS NULL AND alert_next<=? ORDER BY alert_next LIMIT 8`, now).toArray();
        for (const report of due) {
            if (!this.row("SELECT id FROM reports WHERE id=? AND reviewed_at IS NULL", report.id)) continue;
            try {
                // The email contains a private console link. User-submitted
                // words stay in the review queue and out of the inbox.
                const modPath = moderationPath(this.env);
                if (!modPath) throw Error("The moderator path is unavailable.");
                const queuePath = this.ctx.id.name === womenStoreName ? `${modPath}/women` : modPath;
                await this.sendAlert("dysociate forum: post reported", `A published post was reported.\n\nReview it here:\n${this.env.PUBLIC_ORIGIN}${queuePath}?report=${report.id}\n`);
                this.sql.exec("UPDATE reports SET alert_sent_at=?,alert_next=NULL WHERE id=?", Date.now(), report.id);
            } catch {
                const attempts = report.alert_attempts + 1;
                const retryAt = attempts < alertAttempts ? Date.now() + Math.min(6 * 3600, 60 * 2 ** (attempts - 1)) * 1000 : null;
                this.sql.exec("UPDATE reports SET alert_attempts=?,alert_next=? WHERE id=?", attempts, retryAt, report.id);
            }
        }
        await this.scheduleAlert();
    }
}
