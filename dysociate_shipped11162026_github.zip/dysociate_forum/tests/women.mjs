/* Copyright (c) 2026 Luna Love ~ LunaSoft. GPL-3.0-or-later. */

import assert from "node:assert/strict";
import {randomUUID} from "node:crypto";
import {setTimeout} from "node:timers/promises";

const origin = new URL(process.argv[2]);
assert.equal(origin.hostname, "127.0.0.1", "Run against an isolated local forum.");
const moderatorKey = process.env.FORUM_TEST_KEY;
const modPath = process.env.FORUM_TEST_MOD_PATH;
assert.match(moderatorKey, /^[A-Za-z0-9_-]{43}$/);
assert.match(modPath, /^\/forum\/mod[A-Za-z0-9_$-]+$/);

const forum = "/forum/women";
const queue = `${modPath}/women`;
const invites = `${queue}?view=invites`;
const marker = randomUUID();
const label = `<Guest ${marker}>`;
const body = `Private topic ${marker}`;
const url = path => new URL(path, origin);
const get = (path, cookie) => fetch(url(path), {
    headers: cookie ? {Cookie:cookie} : {}, redirect:"manual", signal:AbortSignal.timeout(8000),
});
const post = (path, fields, cookie, requestOrigin = origin.origin) => {
    const headers = {Origin:requestOrigin, "CF-Connecting-IP":"192.0.2.12"};
    if (cookie) headers.Cookie = cookie;
    return fetch(url(path), {method:"POST", body:new URLSearchParams(fields), redirect:"manual", signal:AbortSignal.timeout(8000), headers});
};

const gate = await get(forum);
assert.equal(gate.status, 200);
assert.equal(gate.headers.get("X-Robots-Tag"), "noindex");
assert.equal(gate.headers.get("Cache-Control"), "no-store");
assert.match(await gate.text(), /Invitation key/);
assert.equal((await post(forum, {title:"Blocked", body})).status, 403);
assert.equal((await post(`${queue}/create-invite`, {label})).status, 403);

const login = await post(`${queue}/sign-in`, {key:moderatorKey, view:"invites"});
assert.equal(login.status, 303);
assert.equal(login.headers.get("Location"), invites);
const modCookie = login.headers.get("Set-Cookie").split(";")[0];
assert.match(await (await get(forum, modCookie)).text(), /Invitation key/);
assert.equal((await post(`${queue}/create-invite`, {label}, modCookie, "https://example.org")).status, 403);

const created = await post(`${queue}/create-invite`, {label}, modCookie);
assert.equal(created.status, 201);
const key = (await created.text()).match(/value="([A-Za-z0-9_-]{43})" readonly/)?.[1];
assert.ok(key);
const list = await (await get(invites, modCookie)).text();
assert.ok(list.includes(`&lt;Guest ${marker}&gt;`));
assert.ok(!list.includes(key));
const inviteId = list.match(/name="id" value="([0-9a-f-]+)"/)?.[1];
assert.ok(inviteId);
assert.equal((await post(`${forum}/unlock`, {key:moderatorKey})).status, 401);

const unlocked = await post(`${forum}/unlock`, {key, next:"//example.org"});
assert.equal(unlocked.status, 303);
assert.equal(unlocked.headers.get("Location"), forum);
assert.match(unlocked.headers.get("Set-Cookie"), /HttpOnly; SameSite=Strict/);
const memberCookie = unlocked.headers.get("Set-Cookie").split(";")[0];
assert.ok(!memberCookie.includes(key));
const forgedModerator = memberCookie.replace(/^dysociate-forum-women-local=/, "dysociate-forum-mod-local=");
assert.equal((await post(`${queue}/create-invite`, {label}, forgedModerator)).status, 403);
assert.equal((await post(`${modPath}/sign-in`, {key})).status, 401);

const pending = await post(forum, {title:"Private topic", body}, memberCookie);
assert.equal(pending.status, 303);
const receipt = pending.headers.get("Location");
const id = receipt.split("/").at(-1);
const topic = `${forum}/topic/${id}`;
assert.match(await (await get(receipt, memberCookie)).text(), /Pending review/);
assert.match(await (await get(receipt)).text(), /Invitation key/);
assert.equal((await get(topic, memberCookie)).status, 404);
assert.ok((await (await get(queue, modCookie)).text()).includes(`&lt;Guest ${marker}&gt;`));
assert.ok(!(await (await get(modPath, modCookie)).text()).includes(marker));
assert.equal((await post(`${modPath}/decision`, {action:"approve", id}, modCookie)).status, 409);
assert.equal((await post(`${queue}/decision`, {action:"approve", id}, modCookie)).status, 303);
assert.match(await (await get(receipt, memberCookie)).text(), /Your submission was approved/);
assert.ok(!(await (await get(topic)).text()).includes(marker));
assert.equal((await get(`/forum/topic/${id}`, memberCookie)).status, 404);
const published = await (await get(topic, memberCookie)).text();
assert.ok(published.includes(body));
assert.ok(!published.includes(label) && !published.includes("&lt;Guest"));
assert.ok(published.includes(`${topic}/reply`));
assert.equal((await post(`${forum}/unlock`, {key, next:topic})).headers.get("Location"), topic);

const replyBody = `Private reply ${marker}`;
const reply = await post(`${topic}/reply`, {body:replyBody}, memberCookie);
assert.equal(reply.status, 303);
const replyId = reply.headers.get("Location").split("/").at(-1);
assert.ok(!(await (await get(topic, memberCookie)).text()).includes(replyBody));
assert.equal((await post(`${queue}/decision`, {action:"approve", id:replyId}, modCookie)).status, 303);
assert.ok((await (await get(topic, memberCookie)).text()).includes(replyBody));

assert.equal((await post(`${forum}/report/${replyId}`, {reason:"other"}, memberCookie)).status, 303);
let reports;
for (let attempt = 0; attempt < 12; attempt++) {
    reports = await (await get(`${queue}?view=reports`, modCookie)).text();
    if (reports.includes("Email sent")) break;
    await setTimeout(500);
}
assert.match(reports, /Email sent/);
assert.ok(reports.includes(replyBody));
assert.ok(!(await (await get(`${modPath}?view=reports`, modCookie)).text()).includes(marker));

assert.match((await post(`${forum}/leave`, {}, memberCookie)).headers.get("Set-Cookie"), /Max-Age=0/);
assert.equal((await post(`${queue}/revoke-invite`, {id:inviteId}, modCookie)).status, 303);
assert.match(await (await get(topic, memberCookie)).text(), /Invitation key/);
assert.equal((await post(`${topic}/reply`, {body:"Blocked"}, memberCookie)).status, 403);
assert.equal((await post(`${forum}/unlock`, {key})).status, 401);
assert.match(await (await get(invites, modCookie)).text(), /Revoked/);
console.log("PASS moderator-only invitations, private submissions and reports, approval, and revocation");
