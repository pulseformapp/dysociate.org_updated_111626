/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later.
 */

import assert from "node:assert/strict";
import {randomUUID} from "node:crypto";
import {setTimeout} from "node:timers/promises";

const origin = new URL(process.argv[2]);
assert.equal(origin.hostname, "127.0.0.1", "Run this test against an isolated local forum.");
const key = process.env.FORUM_TEST_KEY;
assert.match(key, /^[A-Za-z0-9_-]{43}$/);
const modPath = process.env.FORUM_TEST_MOD_PATH;
assert.match(modPath, /^\/forum\/mod[A-Za-z0-9_$-]+$/);
const decision = `${modPath}/decision`;
const request = (path, options = {}) => fetch(new URL(path, origin), {
    redirect: "manual", signal: AbortSignal.timeout(8000), ...options,
});
const post = (path, fields, headers = {}) => request(path, {
    method: "POST", body: new URLSearchParams(fields), headers: {Origin: origin.origin, ...headers},
});
const marker = randomUUID();
const privateMarker = randomUUID();
const answers = {step:"questionnaire", gender:"Prefer not to say " + privateMarker,
    topic:"<strong>Test discussion</strong>", discovery:"Test invitation " + privateMarker};
const complete = (path, draft) => post(path, {...draft, ...answers});
const title = "Moderation test " + marker;
const copy = "<script>blocked-" + marker + "</script>";

const basic = await request("/forum");
assert.equal(basic.status, 200);
assert.equal(basic.headers.get("Cache-Control"), "no-store");
assert.match(basic.headers.get("Content-Security-Policy"), /default-src 'none'/);
assert.ok(!(await basic.text()).includes(modPath), "The public forum never includes the moderator address");
const retired = await request("/forum/mod");
assert.equal(retired.status, 404);
assert.equal(retired.headers.get("Location"), null);
assert.ok(!(await retired.text()).includes(modPath));
const signInPage = await request(modPath.replaceAll("$", "%24"));
assert.equal(signInPage.status, 200);
assert.equal(signInPage.headers.get("X-Robots-Tag"), "noindex");
assert.ok((await signInPage.text()).includes(`action="${modPath}/sign-in"`));
assert.equal((await post("/forum", {title, body:copy}, {Origin:"https://example.org"})).status, 403);
const questions = await post("/forum", {title, body:copy});
assert.equal(questions.status, 200);
assert.equal(questions.headers.get("Location"), null);
const formHTML = await questions.text();
assert.match(formHTML, /Submission questions/);
for (const name of ["gender", "topic", "discovery"]) assert.match(formHTML, new RegExp(`name="${name}"[^>]* required`));
assert.match(formHTML, /none of your responses on this form will disqualify your submission/);
const incomplete = await post("/forum", {title, body:copy, ...answers, gender:" "});
assert.equal(incomplete.status, 400);
assert.equal(incomplete.headers.get("Location"), null);
assert.match(await incomplete.text(), /Fill out all three answers/);
const pending = await complete("/forum", {title, body:copy});
assert.equal(pending.status, 303);
const receipt = pending.headers.get("Location");
const topicId = receipt.split("/").at(-1);
const topicPath = `/forum/topic/${topicId}`;
const privateState = await request(receipt);
assert.equal(privateState.headers.get("X-Robots-Tag"), "noindex");
assert.match(await privateState.text(), /Pending review/);
assert.ok(!(await (await request("/forum")).text()).includes(marker));
assert.equal((await request(topicPath)).status, 404);
assert.equal((await post(`/forum/report/${topicId}`, {reason:"hate"})).status, 404);
assert.equal((await post(decision, {action:"approve", id:topicId})).status, 403);
assert.ok(!(await (await request(modPath)).text()).includes(marker));

assert.equal((await post(`${modPath}/sign-in`, {key:"wrong"})).status, 401);
const login = await post(`${modPath}/sign-in`, {key});
assert.equal(login.status, 303);
const cookie = login.headers.get("Set-Cookie");
assert.match(cookie, /HttpOnly; SameSite=Strict/);
const auth = {Cookie:cookie.split(";")[0]};
const review = await (await request(modPath, {headers:auth})).text();
assert.match(review, new RegExp(marker));
assert.equal(review.split("Moderation test " + marker).length, 2, "Only the completed submission reaches the queue");
assert.match(review, /Submission answers/);
assert.ok(review.includes(privateMarker));
assert.ok(review.includes("&lt;strong&gt;Test discussion&lt;/strong&gt;"));
assert.ok(!(await (await request(modPath)).text()).includes(privateMarker));
assert.equal((await post("/forum/mod/decision", {action:"approve", id:topicId}, auth)).status, 404);
assert.equal((await post(decision, {action:"approve", id:topicId}, {...auth, Origin:"https://example.org"})).status, 403);
assert.equal((await post(decision, {action:"approve", id:topicId}, auth)).status, 303);
assert.equal((await post(decision, {action:"approve", id:topicId}, auth)).status, 409);
assert.match(await (await request(receipt)).text(), /Your submission was approved/);
const approved = await (await request(topicPath)).text();
assert.ok(approved.includes("&lt;script&gt;blocked-" + marker));
assert.ok(!approved.includes(copy));
assert.ok(!approved.includes(privateMarker));
assert.ok(!(await (await request("/forum")).text()).includes(privateMarker));

const replyQuestions = await post(topicPath + "/reply", {body:"Reply " + marker});
assert.equal(replyQuestions.status, 200);
assert.match(await replyQuestions.text(), /Submission questions/);
const reply = await complete(topicPath + "/reply", {body:"Reply " + marker});
assert.equal(reply.status, 303);
const replyReceipt = reply.headers.get("Location");
const replyId = replyReceipt.split("/").at(-1);
assert.ok(!(await (await request(topicPath)).text()).includes("Reply " + marker));
assert.equal((await post(decision, {action:"approve", id:replyId}, auth)).status, 303);
assert.ok((await (await request(topicPath)).text()).includes("Reply " + marker));
assert.ok(!(await (await request(topicPath)).text()).includes(privateMarker));

const firstReport = await post(`/forum/report/${replyId}`, {reason:"hate", details:"Review this reply " + marker});
assert.equal(firstReport.status, 303);
const repeatReport = await post(`/forum/report/${replyId}`, {reason:"other"});
assert.equal(repeatReport.status, 303);
assert.ok((await (await request(topicPath)).text()).includes("Reply " + marker));
assert.ok(!(await (await request(`${modPath}?view=reports`)).text()).includes(marker));
let casePage;
for (let attempt = 0; attempt < 12; attempt++) {
    casePage = await (await request(`${modPath}?view=reports`, {headers:auth})).text();
    if (casePage.includes("2 report(s) · Email sent")) break;
    await setTimeout(500);
}
assert.match(casePage, /2 report\(s\) · Email sent/, "Local email binding should accept the alert from the outbox");
assert.ok(casePage.includes(privateMarker));
const reportId = casePage.match(/id="report-([0-9a-f-]+)"/)?.[1];
assert.ok(reportId);
const reportLogin = await post(`${modPath}/sign-in`, {key, report:reportId});
assert.equal(reportLogin.headers.get("Location"), `${modPath}?report=${reportId}`);
assert.equal((await post(decision, {action:"remove", id:replyId}, auth)).status, 303);
assert.ok(!(await (await request(topicPath)).text()).includes("Reply " + marker));
assert.match(await (await request(replyReceipt)).text(), /no longer available/);
assert.match(await (await request(`${modPath}?view=reports`, {headers:auth})).text(), /No open reports/);

const declined = await complete(topicPath + "/reply", {body:"Declined test " + marker});
assert.equal(declined.status, 303);
const declinedReceipt = declined.headers.get("Location");
assert.equal((await post(decision, {action:"decline", id:declinedReceipt.split("/").at(-1)}, auth)).status, 303);
assert.match(await (await request(declinedReceipt)).text(), /A moderator declined/);
assert.ok(!(await (await request(topicPath)).text()).includes("Declined test " + marker));

const publishedPage = `${modPath}?view=published`;
const directRemoval = `${decision}?view=published`;
const signIn = await (await request(publishedPage)).text();
assert.match(signIn, /name="view" value="published"/);
assert.ok(!signIn.includes(marker));
assert.equal((await post(`${modPath}/sign-in`, {key, view:"published"})).headers.get("Location"), publishedPage);
const cleanReply = await complete(topicPath + "/reply", {body:"Unreported reply " + marker});
assert.equal(cleanReply.status, 303);
const cleanId = cleanReply.headers.get("Location").split("/").at(-1);
assert.ok(!(await (await request(publishedPage, {headers:auth})).text()).includes("Unreported reply " + marker));
assert.equal((await post(decision, {action:"approve", id:cleanId}, auth)).status, 303);
const published = await (await request(publishedPage, {headers:auth})).text();
assert.match(published, /aria-current="page">Published/);
assert.ok(published.includes("Unreported reply " + marker));
assert.ok(published.includes(privateMarker));
assert.ok(!published.includes("Declined test " + marker));
assert.ok(published.includes(`action="${directRemoval}"`));
assert.equal((await post(directRemoval, {action:"remove", id:cleanId})).status, 403);
const removedReply = await post(directRemoval, {action:"remove", id:cleanId}, auth);
assert.equal(removedReply.status, 303);
assert.equal(removedReply.headers.get("Location"), publishedPage);
const publicTopic = await request(topicPath);
assert.equal(publicTopic.status, 200);
assert.ok(!(await publicTopic.text()).includes("Unreported reply " + marker));

const child = await complete(topicPath + "/reply", {body:"Reply under removed topic " + marker});
assert.equal(child.status, 303);
const childReceipt = child.headers.get("Location");
assert.equal((await post(decision, {action:"approve", id:childReceipt.split("/").at(-1)}, auth)).status, 303);
const removedTopic = await post(directRemoval, {action:"remove", id:topicId}, auth);
assert.equal(removedTopic.status, 303);
assert.equal(removedTopic.headers.get("Location"), publishedPage);
assert.equal((await request(topicPath)).status, 404);
assert.match(await (await request(childReceipt)).text(), /no longer available/);
assert.ok(!(await (await request(publishedPage, {headers:auth})).text()).includes(marker));
const signedOut = await post(`${modPath}/sign-out`, {}, auth);
assert.equal(signedOut.status, 303);
assert.equal(signedOut.headers.get("Location"), modPath);
console.log("PASS required questionnaire, private answers, moderator access, publication, reporting, email outbox and direct removal");
