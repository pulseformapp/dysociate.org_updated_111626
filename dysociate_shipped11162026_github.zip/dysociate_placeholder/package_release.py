"""Stage verified dλsociate release files beside the official site.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""

import argparse
from hashlib import file_digest
from pathlib import Path
from shutil import copy2
from zipfile import ZIP_DEFLATED, ZipFile


SITE = Path(__file__).resolve().parent
OUTPUTS = SITE.parent
STATIC_LIMIT = 25 * 1024 * 1024


def add_tree(archive, folder, target):
    for source in sorted(folder.rglob('*')):
        if source.is_file() and '__pycache__' not in source.parts:
            archive.write(source, (target / source.relative_to(folder)).as_posix())


def stage_release(windows, android, version, *, windows_version=None):
    downloads = SITE / 'dist' / 'downloads'
    downloads.mkdir(exist_ok=True)
    installer = windows / 'dysociate-setup.exe'
    if any(path.stat().st_size > STATIC_LIMIT for path in (installer, android)):
        raise ValueError('An installer exceeds the Cloudflare static file limit of 25 MiB.')

    source_zip = downloads / f'dysociate-{version}-source.zip'
    with ZipFile(source_zip, 'w', ZIP_DEFLATED) as archive:
        add_tree(archive, windows / 'Source', Path('python_pagebuilder'))
        add_tree(archive, OUTPUTS / 'dysociate_android' / 'app', Path('dysociate_android/app'))
        add_tree(archive, OUTPUTS / 'dysociate_android' / 'tests', Path('dysociate_android/tests'))
        for name in ('build.ps1', 'build_assets.py', 'LICENSE', 'README.md', 'test_android.mjs'):
            archive.write(OUTPUTS / 'dysociate_android' / name, f'dysociate_android/{name}')
        live = OUTPUTS / 'dysociate_live'
        for folder in ('web', 'contract', 'tests'):
            add_tree(archive, live / folder, Path('dysociate_live') / folder)
        for entry in sorted(live.iterdir()):
            if entry.is_file() and (entry.suffix in {'.mjs', '.jsonc'} or entry.name in {'LICENSE', 'README.md'}):
                archive.write(entry, f'dysociate_live/{entry.name}')
        for icon in ('icon-180.png', 'icon-192.png', 'icon-512.png'):
            archive.write(OUTPUTS / 'dysociate_ios_web' / 'dist' / icon, f'dysociate_ios_web/dist/{icon}')
        for name in ('index.html', 'guide.html', 'about.html', 'thread-count.js', '_headers'):
            archive.write(SITE / 'dist' / name, f'dysociate_placeholder/dist/{name}')
        add_tree(archive, SITE / 'dist' / 'assets', Path('dysociate_placeholder/dist/assets'))
        for name in ('worker.mjs', 'wrangler.jsonc', 'package_release.py', 'RELEASE.md'):
            archive.write(SITE / name, f'dysociate_placeholder/{name}')
        archive.write(OUTPUTS / 'dysociate-release-engineering-spec.md', 'dysociate-release-engineering-spec.md')

    with ZipFile(source_zip) as archive:
        if archive.testzip() or source_zip.stat().st_size > STATIC_LIMIT:
            raise ValueError('The source archive failed validation or exceeds the static file limit.')

    windows_download = downloads / f'dysociate-{windows_version or version}-windows-x64.exe'
    android_download = downloads / f'dysociate-{version}.apk'
    copy2(installer, windows_download)
    copy2(android, android_download)
    hashes = []
    for path in (windows_download, android_download, source_zip):
        with path.open('rb') as source:
            hashes.append(f'{file_digest(source, "sha256").hexdigest()}  {path.name}')
    (downloads / 'SHA256SUMS.txt').write_text('\n'.join(hashes) + '\n', encoding='ascii')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('windows', type=Path, help='Staged Windows package containing the setup EXE and Source')
    parser.add_argument('android', type=Path, help='Verified Android release APK')
    parser.add_argument('version', help='Public release version used in download filenames')
    parser.add_argument('--windows-version', help='Keep an earlier Windows installer version in a mobile-only release')
    args = parser.parse_args()
    stage_release(args.windows, args.android, args.version, windows_version=args.windows_version)
