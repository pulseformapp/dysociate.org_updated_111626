/* Copyright (c) 2026 Luna Love ~ LunaSoft. GPL-3.0-or-later. */

import {EmailMessage} from "cloudflare:email";

const sender = "alerts@dysociate.org";
const inbox = "luna@dysociate.org";
const maxFormBytes = 4096;
const emailPattern = /^[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9-]+(?:\.[A-Z0-9-]+)+$/i;

async function readForm(request) {
    const type = request.headers.get("Content-Type")?.split(";")[0].trim().toLowerCase();
    if (type !== "application/x-www-form-urlencoded" || !request.body) return null;

    const reader = request.body.getReader();
    const decoder = new TextDecoder();
    let encoded = "";
    let size = 0;
    try {
        for (;;) {
            const {done, value} = await reader.read();
            if (done) return new URLSearchParams(encoded + decoder.decode());
            size += value.byteLength;
            if (size > maxFormBytes) {
                await reader.cancel();
                return null;
            }
            encoded += decoder.decode(value, {stream: true});
        }
    } finally {
        reader.releaseLock();
    }
}

function inquiryMessage(name, email) {
    // The address is validated before it is used in Reply-To. The name and
    // address also appear as UTF-8 text in the body for the inbox reader.
    const text = `A visitor requested donation instructions from dysociate.org.\r\n\r\nName: ${name}\r\nEmail: ${email}\r\n`;
    const body = new TextEncoder().encode(text).toBase64().match(/.{1,76}/g).join("\r\n");
    const raw = [
        `From: dysociate donations <${sender}>`, `To: ${inbox}`, `Reply-To: ${email}`,
        "Subject: dysociate donation inquiry", `Date: ${new Date().toUTCString()}`,
        `Message-ID: <${crypto.randomUUID()}@dysociate.org>`, "MIME-Version: 1.0",
        "Content-Type: text/plain; charset=UTF-8", "Content-Transfer-Encoding: base64", "", body, "",
    ].join("\r\n");
    return new EmailMessage(sender, inbox, raw);
}

async function render(request, env, {status = 200, message = "", name = "", email = "", sent = false} = {}) {
    // Always load the form template as a GET. POST bodies and submitted
    // addresses stay out of the asset request and any cache keys.
    const template = await env.ASSETS.fetch(new Request(new URL("/support", request.url)));
    if (!template.ok) return template;
    const page = new Response(template.body, {status, headers: template.headers});
    page.headers.delete("ETag");
    page.headers.delete("Last-Modified");
    page.headers.set("Cache-Control", "no-store");
    page.headers.set("Content-Security-Policy", "default-src 'none'; style-src 'self'; img-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'");
    if (!message) return page;

    const view = new HTMLRewriter().on("#donation-status", {element(node) {
        node.removeAttribute("hidden");
        node.setAttribute("role", sent ? "status" : "alert");
        node.setInnerContent(message);
    }});
    if (sent) {
        return view.on("#donation-intro, #donation-form", {element: node => node.remove()}).transform(page);
    }
    return view.on("#donor-name", {element: node => node.setAttribute("value", name.slice(0, 120))})
        .on("#donor-email", {element: node => node.setAttribute("value", email.slice(0, 254))})
        .transform(page);
}

export async function supportPage(request, env) {
    const url = new URL(request.url);
    if (request.method === "GET") {
        const sent = url.searchParams.get("sent") === "1";
        return render(request, env, {sent, message: sent ? "Thanks for reaching out. Luna will email you with donation instructions." : ""});
    }
    if (request.headers.get("Origin") !== url.origin) {
        return render(request, env, {status: 403, message: "Open the donation page and submit the form again."});
    }

    const fields = await readForm(request);
    const name = fields?.get("name")?.trim() || "";
    const email = fields?.get("email")?.trim() || "";
    if (!name || name.length > 120 || /[\p{Cc}\p{Zl}\p{Zp}]/u.test(name) || email.length > 254 || !emailPattern.test(email)) {
        return render(request, env, {status: 400, message: "Enter your name and a valid email address.", name, email});
    }

    try {
        const ip = request.headers.get("CF-Connecting-IP") || "loopback";
        const {success} = await env.DONATION_RATE.limit({key: ip});
        if (!success) {
            return render(request, env, {status: 429, message: "Too many requests. Try again in a minute.", name, email});
        }
        await env.DONATION_REQUESTS.send(inquiryMessage(name, email));
    } catch {
        return render(request, env, {status: 503, message: "We couldn’t send your request. Please try again in a moment.", name, email});
    }

    // A refresh repeats only the confirmation GET, so it cannot resend mail.
    return new Response(null, {status: 303, headers: {Location: "/support?sent=1", "Cache-Control": "no-store"}});
}
