/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

const SLOT_COUNT = 256;
const MAX_HTML_BYTES = 8 * 1024 * 1024;
const noncePattern = /^[a-f0-9]{32}$/;
const linkPattern = /^(\d{3})-([a-f0-9]{32})$/;
const encoder = new TextEncoder();
const headers = {
    "Cache-Control": "no-store",
    "Referrer-Policy": "no-referrer",
    "X-Content-Type-Options": "nosniff",
    "X-Robots-Tag": "noindex, nofollow, noarchive",
};
const htmlHeaders = {
    ...headers,
    "Content-Type": "text/html; charset=utf-8",
    // The exported editor uses inline JS and embedded images. Give uploaded
    // documents an opaque origin and prevent background network requests.
    // The local composer needs submit events. form-action still blocks any
    // actual form submission to a server.
    "Content-Security-Policy": "sandbox allow-scripts allow-downloads allow-forms allow-modals allow-popups allow-popups-to-escape-sandbox; "
        + "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; media-src blob:; "
        + "connect-src 'none'; form-action 'none'; base-uri 'none'; frame-ancestors 'none'",
};

const json = (status, payload) => Response.json(payload, {status, headers});
const failure = (status, error) => json(status, {error});

function slotKey(slot) {
    return "slot/" + String(slot).padStart(3, "0");
}

function parseLink(value) {
    const match = linkPattern.exec(value);
    if (!match || Number(match[1]) >= SLOT_COUNT) return null;
    return {key: "slot/" + match[1], id: match[2]};
}

async function authorized(request, secret) {
    const header = request.headers.get("Authorization") || "";
    if (typeof secret !== "string" || secret.length < 32 || secret.length > 256
        || !header.startsWith("Bearer ") || header.length > 263) return false;
    const key = await crypto.subtle.importKey("raw", encoder.encode(secret),
        {name: "HMAC", hash: "SHA-256"}, false, ["sign", "verify"]);
    const message = encoder.encode("dysociate-publisher");
    const supplied = await crypto.subtle.importKey("raw", encoder.encode(header.slice(7) || " "),
        {name: "HMAC", hash: "SHA-256"}, false, ["sign"]);
    return crypto.subtle.verify("HMAC", key, await crypto.subtle.sign("HMAC", supplied, message), message);
}

async function publish(request, env) {
    const nonce = request.headers.get("X-Publish-Id") || "";
    if (!noncePattern.test(nonce)) return failure(400, "The publication ID is invalid.");
    const length = Number(request.headers.get("Content-Length"));
    if (!Number.isInteger(length) || length <= 0) return failure(411, "The HTML file size is required.");
    if (length > MAX_HTML_BYTES) return failure(413, "Published threads can be up to 8 MiB.");
    if (!/^text\/html(?:\s*;|$)/i.test(request.headers.get("Content-Type") || "")) {
        return failure(415, "Upload a dλsociate HTML thread.");
    }
    if (!request.body) return failure(400, "The HTML upload is empty.");
    const html = new Uint8Array(length);
    const reader = request.body.getReader();
    let received = 0;
    try {
        for (let chunk = await reader.read(); !chunk.done; chunk = await reader.read()) {
            if (received + chunk.value.length > length) {
                await reader.cancel();
                return failure(400, "The HTML upload exceeded its declared size.");
            }
            html.set(chunk.value, received);
            received += chunk.value.length;
        }
    } finally {
        reader.releaseLock();
    }
    if (received !== length) return failure(400, "The HTML upload did not match its declared size.");
    if (!/^\s*<!doctype html>/i.test(new TextDecoder().decode(html.slice(0, 64)))) {
        return failure(400, "Upload an exported dλsociate HTML thread.");
    }
    const id = crypto.randomUUID().replaceAll("-", "");
    const hash = new Uint8Array(await crypto.subtle.digest("SHA-256", html)).toHex();
    // A unique comment makes the ETag specific to this publication, even
    // when identical HTML is published again after a slot has been removed.
    const body = new Blob([html, "\n<!-- dλsociate publication " + id + " -->\n"]);
    const link = (key, publishedId) => new URL("/t/" + key.slice(5) + "-" + publishedId, env.PUBLIC_ORIGIN).href;

    // Fixed slots cap stored HTML at 256 × 8 MiB plus the small comments.
    // Conditional writes protect the budget when uploads or removals race.
    for (let attempt = 0; attempt < 3; attempt++) {
        const list = await env.THREADS.list({prefix: "slot/", include: ["customMetadata"], limit: SLOT_COUNT});
        if (list.truncated) return failure(503, "Publishing storage needs attention.");
        const existing = list.objects.find(object => object.customMetadata?.nonce === nonce);
        if (existing) {
            if (existing.customMetadata.hash !== hash) return failure(409, "This publication ID was already used for a different file.");
            return json(200, {url: link(existing.key, existing.customMetadata.id)});
        }
        const objects = new Map(list.objects.map(object => [object.key, object]));
        const key = Array.from({length: SLOT_COUNT}, (_, slot) => slotKey(slot))
            .find(candidate => !objects.has(candidate) || objects.get(candidate).customMetadata?.removed === "1");
        if (!key) return failure(507, "Publishing storage is full. Remove a published copy first.");
        const previous = objects.get(key);
        const condition = previous ? {"If-Match": previous.httpEtag} : {"If-None-Match": "*"};
        const written = await env.THREADS.put(key, body, {
            onlyIf: new Headers(condition),
            customMetadata: {id, nonce, hash},
        });
        if (written) return json(201, {url: link(key, id)});
    }
    return failure(503, "Publishing is busy. Try again.");
}

async function remove(env, target) {
    const current = await env.THREADS.head(target.key);
    if (!current || current.customMetadata?.id !== target.id) return new Response(null, {status: 204, headers});
    const removed = await env.THREADS.put(target.key, crypto.randomUUID(), {
        onlyIf: new Headers({"If-Match": current.httpEtag}),
        customMetadata: {removed: "1"},
    });
    if (!removed) return failure(409, "The published copy changed. Try again.");
    return new Response(null, {status: 204, headers});
}

export default {
    async fetch(request, env) {
        const path = new URL(request.url).pathname;
        try {
            if (request.method === "POST" && path === "/api/threads") {
                if (!await authorized(request, env.PUBLISH_KEY)) return failure(401, "Check your publisher key.");
                return await publish(request, env);
            }
            if (request.method === "DELETE" && path.startsWith("/api/threads/")) {
                if (!await authorized(request, env.PUBLISH_KEY)) return failure(401, "Check your publisher key.");
                const target = parseLink(path.slice("/api/threads/".length));
                return target ? await remove(env, target) : failure(404, "Thread not found.");
            }
            if (request.method === "GET" && path === "/healthz") {
                return new Response(null, {status: 204, headers});
            }
            if ((request.method === "GET" || request.method === "HEAD") && path.startsWith("/t/")) {
                const target = parseLink(path.slice(3));
                if (!target) return failure(404, "Thread not found.");
                const object = request.method === "HEAD" ? await env.THREADS.head(target.key) : await env.THREADS.get(target.key);
                if (!object || object.customMetadata?.id !== target.id) return failure(404, "Thread not found.");
                return new Response(object.body || null, {headers: htmlHeaders});
            }
            return failure(404, "Thread not found.");
        } catch {
            return failure(503, "The publishing service is unavailable. Try again.");
        }
    },
};
