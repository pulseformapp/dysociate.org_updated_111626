"""Create synthetic desktop thread and photo fixtures for the Android tests.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""
import argparse
from pathlib import Path
import sys

from PIL import Image


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("destination", type=Path)
args = parser.parse_args()
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "python_pagebuilder"))
from pagebuilder_gui import Page, Section, render_document

page = Page(
    title="Desktop Android round trip",
    sections=[
        Section("Post", heading="Windows post", body="Created with the desktop renderer", post_id="desktop-root"),
        Section("Post", body="Existing reply", post_id="desktop-reply", parent_id="desktop-root"),
    ],
)
args.destination.mkdir(parents=True, exist_ok=True)
# Deliberately hostile received code verifies that the importer reads the
# embedded data model without executing the received document's scripts.
document = render_document(page).replace(
    "</body>", "<script>window.untrustedAttachment=true;</script></body>"
)
(args.destination / "Dysociate-Android-QA.html").write_text(document, encoding="utf-8")
Image.new("RGB", (180, 125), "#a8ff60").save(args.destination / "Photo-QA.png")
print(args.destination.resolve())
