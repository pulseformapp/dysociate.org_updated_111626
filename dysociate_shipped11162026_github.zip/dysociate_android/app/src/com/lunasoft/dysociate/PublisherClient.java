/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
package com.lunasoft.dysociate;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

final class PublisherClient {
    private static final String ORIGIN = "https://threads.dysociate.org";
    private static final String ENDPOINT = ORIGIN;
    private static final long MAX_BYTES = 8L * 1024 * 1024;

    static boolean validKey(String key) {
        return key.matches("[A-Za-z0-9_-]{32,256}");
    }

    static boolean validLink(String link) {
        return link.matches(java.util.regex.Pattern.quote(ORIGIN) + "/t/[0-9]{3}-[a-f0-9]{32}");
    }

    static String publish(File file, String key) {
        if (file.length() > MAX_BYTES) throw new IllegalArgumentException("Published threads can be up to 8 MiB. Use fewer or smaller images.");
        String id = UUID.randomUUID().toString().replace("-", "");
        String link = request("POST", "/api/threads", key, file, id).optString("url");
        if (!validLink(link)) throw new IllegalArgumentException("The service returned an invalid thread link.");
        return link;
    }

    static void remove(String link, String key) {
        if (!validLink(link)) throw new IllegalArgumentException("The thread link is invalid.");
        request("DELETE", "/api/threads/" + link.substring((ORIGIN + "/t/").length()), key, null, null);
    }

    private static JSONObject request(String method, String path, String key, File file, String id) {
        if (!validKey(key)) throw new IllegalArgumentException("Enter a valid publisher key.");
        for (int attempt = 0; attempt < 2; attempt++) {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(ENDPOINT + path).openConnection();
                connection.setRequestMethod(method);
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(12000);
                connection.setInstanceFollowRedirects(false);
                connection.setRequestProperty("Authorization", "Bearer " + key);
                if (file != null) {
                    connection.setRequestProperty("Content-Type", "text/html; charset=utf-8");
                    connection.setRequestProperty("X-Publish-Id", id);
                    connection.setFixedLengthStreamingMode(file.length());
                    connection.setDoOutput(true);
                    try (OutputStream output = connection.getOutputStream()) {
                        Files.copy(file.toPath(), output);
                    }
                }
                int status = connection.getResponseCode();
                if (status == 204) return new JSONObject();
                boolean success = status == 200 || status == 201;
                JSONObject response = response(success ? connection.getInputStream() : connection.getErrorStream());
                if (success) return response;
                if (status == 401) throw new IllegalArgumentException("The publisher key was rejected.");
                throw new IllegalArgumentException(response.optString("error", "The publishing service returned HTTP " + status + "."));
            } catch (IOException error) {
                // Retry the same upload ID if a response is lost. The service
                // returns the link already assigned to that upload.
                if (attempt == 1) break;
            } finally {
                if (connection != null) connection.disconnect();
            }
        }
        throw new IllegalArgumentException("Could not reach the publishing service. Check the connection and try again.");
    }

    private static JSONObject response(InputStream input) throws IOException {
        if (input == null) return new JSONObject();
        try (InputStream source = input; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[1024];
            for (int read; (read = source.read(buffer)) != -1;) {
                if (output.size() + read > 4096) throw new IllegalArgumentException("The publishing service returned an invalid response.");
                output.write(buffer, 0, read);
            }
            try {
                return new JSONObject(new String(output.toByteArray(), StandardCharsets.UTF_8));
            } catch (JSONException error) {
                return new JSONObject();
            }
        }
    }
}
