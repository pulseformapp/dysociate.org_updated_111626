/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import {writeFile} from "node:fs/promises";

const [path, subject] = process.argv.slice(2);
if (!path || !subject || !/^(https:\/\/|mailto:)[^\s"\\]+$/.test(subject))
    throw Error("Usage: node push-keygen.mjs <new secret JSON file> <HTTPS contact URL or mailto address>");

const keys = await crypto.subtle.generateKey({name: "ECDSA", namedCurve: "P-256"}, true, ["sign", "verify"]);
const privateKey = await crypto.subtle.exportKey("jwk", keys.privateKey);
const publicKey = Buffer.from(await crypto.subtle.exportKey("raw", keys.publicKey)).toString("base64url");
const secrets = {PUSH_VAPID_PRIVATE_JWK: JSON.stringify(privateKey), PUSH_VAPID_PUBLIC_KEY: publicKey, PUSH_VAPID_SUBJECT: subject};
await writeFile(path, JSON.stringify(secrets, null, 2), {flag: "wx", mode: 0o600});
console.log("Generated a new Web Push key set in the requested file.");
