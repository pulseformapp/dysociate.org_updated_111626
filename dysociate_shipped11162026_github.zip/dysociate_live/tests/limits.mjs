/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import assert from "node:assert/strict";
import {randomUUID} from "node:crypto";
import {setTimeout as pause} from "node:timers/promises";

const [limited, paused] = process.argv.slice(2).map(value => new URL(value));
for (const origin of [limited, paused]) {
    assert.ok(origin.protocol === "http:" && origin.hostname === "127.0.0.1", "Use loopback only.");
}

async function call(origin, path, method = "GET", payload, credential) {
    const headers = {};
    if (credential) headers.Authorization = "Bearer " + credential;
    if (payload !== undefined) headers["Content-Type"] = "application/json";
    const response = await fetch(new URL("/api/v1" + path, origin), {
        method, headers, body: payload === undefined ? undefined : JSON.stringify(payload),
        signal: AbortSignal.timeout(5000),
    });
    return {status: response.status, retryAfter: response.headers.get("Retry-After"), body: await response.json()};
}

const session = await call(limited, "/session", "POST", {client: "native"});
assert.equal(session.status, 201);
const credential = session.body.credential;
const draft = {operationId: randomUUID(), title: "Synthetic limit test", openingPost: {body: "Opening"}};
const pausedResult = await call(paused, "/threads", "POST", draft, credential);
assert.equal(pausedResult.status, 503);
assert.equal(pausedResult.body.error.code, "writes_paused");
assert.equal(pausedResult.retryAfter, "60");
assert.equal((await call(paused, "/threads", "POST", draft)).status, 401);

const created = await call(limited, "/threads", "POST", draft, credential);
assert.equal(created.status, 201);
const path = new URL(created.body.shareUrl).pathname.replace(/^\/t\//, "/threads/");
const first = {operationId: randomUUID(), body: "First reply", parentId: created.body.post.id};
const second = {operationId: randomUUID(), body: "Second reply", parentId: created.body.post.id};
const post = payload => call(limited, path + "/posts", "POST", payload, credential);
const elapsedInMinute = Date.now() % 60_000;
if (elapsedInMinute > 55_000) await pause(60_100 - elapsedInMinute);
const a = await post(first);
const b = await post(second);
assert.equal(a.status, 201);
assert.equal(b.status, 201);
const rejected = await post({operationId: randomUUID(), body: "Over the limit"});
assert.equal(rejected.status, 429);
assert.equal(rejected.body.error.code, "thread_rate_limited");
assert.equal(rejected.retryAfter, "60");
assert.deepEqual((await post(first)).body, a.body);

const remove = id => call(limited, path + "/posts/" + id, "DELETE", undefined, credential);
assert.equal((await remove(created.body.post.id)).status, 200);
assert.equal((await remove(a.body.post.id)).status, 200);
const capacity = await post({operationId: randomUUID(), body: "Over capacity"});
assert.equal(capacity.status, 409);
assert.equal(capacity.body.error.code, "thread_capacity");
const snapshot = (await call(limited, path)).body;
assert.equal(snapshot.headSeq, 5);
assert.equal(snapshot.posts[0].body, null);
assert.equal(snapshot.posts[2].parentId, created.body.post.id);
assert.equal(snapshot.posts[2].body, second.body);

// The Pilot uses 8 create requests per location and address per minute.
const additional = Array.from({length: 12}, () =>
    call(limited, "/threads", "POST", {...draft, operationId: randomUUID()}, credential));
const results = await Promise.all(additional);
assert.ok(results.some(result => result.status === 429 &&
    result.body.error.code === "rate_limited" && result.retryAfter === "60"));
console.log("PASS edge rate, thread rate, retained history, creation receipts, and paused writes");
