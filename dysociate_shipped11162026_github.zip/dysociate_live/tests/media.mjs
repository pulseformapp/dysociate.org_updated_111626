/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
import assert from "node:assert/strict";
import {randomUUID} from "node:crypto";
import {readFile} from "node:fs/promises";
import {join} from "node:path";

const [address, fixtures] = process.argv.slice(2);
const origin = new URL(address);
assert.ok(origin.hostname === "127.0.0.1" || origin.origin === "https://dysociate-live-pilot.pulseform.workers.dev");
const photo = await readFile(join(fixtures, "photo.png"));
const clip = await readFile(join(fixtures, "clip.mp4"));
const tooLong = await readFile(join(fixtures, "too-long.mp4"));

async function call(path, method, payload, bearer, file, type) {
    const headers = {};
    if (bearer) headers.Authorization = "Bearer " + bearer;
    let body;
    if (file) {
        body = new FormData();
        body.set("payload", JSON.stringify(payload));
        body.set("media", new Blob([file], {type}), "test");
    } else if (payload) {
        headers["Content-Type"] = "application/json";
        body = JSON.stringify(payload);
    }
    const response = await fetch(new URL(path, origin), {method, headers, body});
    return [response.status, await response.json()];
}

const createPath = "/api/v1/threads";
const [, {credential}] = await call("/api/v1/session", "POST", {client: "native"});
const [, {credential: guest}] = await call("/api/v1/session", "POST", {client: "native"});
const opening = {operationId: randomUUID(), title: "Synthetic photo thread", openingPost: {body: ""}};
const created = await call(createPath, "POST", opening, credential, photo, "image/png");
assert.equal(created[0], 201, JSON.stringify(created));
assert.equal(created[1].post.media.type, "image/png");
assert.equal(created[1].post.body, "");
const api = new URL(created[1].shareUrl).pathname.replace(/^\/t\//, createPath + "/");
const openingId = created[1].post.id;
const mediaPath = api + "/media/" + openingId;
const snapshot = await call(api, "GET");
assert.equal(snapshot[1].posts[0].media.type, "image/png");
assert.deepEqual(Buffer.from(await (await fetch(new URL(mediaPath, origin))).arrayBuffer()), photo);
const head = await fetch(new URL(mediaPath, origin), {method: "HEAD"});
assert.equal(head.status, 200);
assert.equal(Number(head.headers.get("Content-Length")), photo.length);
assert.equal((await call(createPath, "POST", opening, credential, photo, "image/png"))[0], 200);

const reply = {operationId: randomUUID(), parentId: openingId, body: "Synthetic reel reply"};
assert.equal((await call(api + "/posts", "POST", reply, guest, Buffer.from("<svg/>"), "image/svg+xml"))[0], 415);
assert.equal((await call(api + "/posts", "POST", reply, guest, Buffer.from("<svg/>"), "image/png"))[0], 422);
assert.equal((await call(api + "/posts", "POST", reply, guest, Buffer.alloc(1024 * 1024 + 1), "image/jpeg"))[0], 413);
const long = await call(api + "/posts", "POST", reply, guest, tooLong, "video/mp4");
assert.equal(long[0], 422);
assert.equal(long[1].error.code, "reel_duration");
const recorded = await call(api + "/posts", "POST", reply, guest, clip, "video/mp4");
assert.equal(recorded[0], 201, JSON.stringify(recorded));
const reel = recorded[1].post;
assert.ok(reel.media.duration > 11 && reel.media.duration < 13);
assert.equal((await call(api + "/posts", "POST", reply, guest, clip, "video/mp4"))[0], 200);
assert.equal((await call(api + "/posts", "POST", reply, guest, photo, "image/png"))[0], 409);

const reelUrl = new URL(api + "/media/" + reel.id, origin);
assert.ok(clip.length > 1_048_585);
const range = await fetch(reelUrl, {headers: {Range: "bytes=1048570-1048585"}});
assert.equal(range.status, 206);
assert.equal(range.headers.get("Content-Range"), "bytes 1048570-1048585/" + clip.length);
assert.deepEqual(Buffer.from(await range.arrayBuffer()), clip.subarray(1048570, 1048586));
assert.equal((await fetch(reelUrl, {headers: {Range: "bytes=" + clip.length + "-"}})).status, 416);
const alternate = await call(createPath, "POST", {...opening, operationId: randomUUID(), openingPost: {body: "Other thread"}}, guest);
const other = new URL(alternate[1].shareUrl).pathname.replace(/^\/t\//, createPath + "/");
assert.equal((await fetch(new URL(other + "/media/" + reel.id, origin))).status, 404);

assert.equal((await call(api + "/posts/" + openingId, "DELETE", undefined, guest))[0], 403);
assert.equal((await call(api + "/posts/" + openingId, "DELETE", undefined, credential))[0], 200);
assert.equal((await fetch(new URL(mediaPath, origin))).status, 404);
const latest = await call(api, "GET");
assert.equal(latest[1].posts[0].media, undefined);
assert.equal(latest[1].posts[1].parentId, openingId);
assert.equal((await call(api + "/posts/" + reel.id, "DELETE", undefined, guest))[0], 200);
assert.equal((await fetch(reelUrl)).status, 404);
console.log("PASS photos, fragmented reels, duration and file limits, cross-chunk playback, retry receipts, and deletion");

if (origin.hostname === "127.0.0.1") {
    // Pad a valid MP4 with a free box so eight reels fill the limit exactly.
    const full = Buffer.alloc(4 * 1024 * 1024);
    clip.copy(full);
    full.writeUInt32BE(full.length - clip.length, clip.length);
    full.write("free", clip.length + 4);
    let first;
    for (let index = 0; index < 8; index++) {
        const posted = await call(other + "/posts", "POST", {...reply, operationId: randomUUID(), parentId: null}, guest, full, "video/mp4");
        assert.equal(posted[0], 201, JSON.stringify(posted));
        first ??= posted[1].post.id;
    }
    const next = {...reply, operationId: randomUUID(), parentId: null};
    const over = await call(other + "/posts", "POST", next, guest, photo, "image/png");
    assert.equal(over[0], 409, JSON.stringify(over));
    assert.equal(over[1].error.code, "media_capacity");
    assert.equal((await call(other + "/posts/" + first, "DELETE", undefined, guest))[0], 200);
    assert.equal((await call(other + "/posts", "POST", next, guest, photo, "image/png"))[0], 201);
    console.log("PASS 32 MiB thread quota and storage reclaimed after author deletion");
}
