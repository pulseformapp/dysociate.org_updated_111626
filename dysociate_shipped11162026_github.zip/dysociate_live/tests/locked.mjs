/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
import assert from "node:assert/strict";
import {randomUUID} from "node:crypto";
import http from "node:http";
import https from "node:https";

const origin = new URL(process.argv[2]);
assert.ok(origin.hostname === "127.0.0.1" || origin.origin === "https://dysociate-live-pilot.pulseform.workers.dev");
const session = "/api/v1/session";
const threads = "/api/v1/threads";
const photo = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j9uoAAAAASUVORK5CYII=", "base64");

async function call(path, method = "GET", actor, payload, extra = {}) {
    const headers = {...extra};
    if (actor?.includes("=")) {
        headers.Cookie = actor;
        headers.Origin ??= origin.origin;
    } else if (actor) headers.Authorization = "Bearer " + actor;
    if (payload && !(payload instanceof FormData)) headers["Content-Type"] = "application/json";
    const body = payload && !(payload instanceof FormData) ? JSON.stringify(payload) : payload;
    return fetch(new URL(path, origin), {method, headers, body, signal: AbortSignal.timeout(12000)});
}

async function expect(status, ...args) {
    const reply = await call(...args);
    assert.equal(reply.status, status, reply.status === status ? args[0] : args[0] + " " + await reply.text());
    return reply;
}

async function native() {
    return (await (await expect(201, session, "POST", null, {client: "native"})).json()).credential;
}

async function browser() {
    const reply = await expect(200, session, "POST", null, {client: "browser"}, {Origin: origin.origin});
    return reply.headers.get("Set-Cookie").split(";")[0];
}

const [owner, guest, codeGuest, outsider, denied] = await Promise.all([native(), browser(), browser(), browser(), browser()]);
const code = "PilotTest-" + randomUUID();
const payload = {operationId: randomUUID(), title: "Synthetic locked thread", openingPost: {body: "Private opening"},
    accessMode: "locked", passkey: code};
const form = () => {
    const body = new FormData();
    body.set("payload", JSON.stringify(payload));
    body.set("media", new Blob([photo], {type: "image/png"}), "test.png");
    return body;
};
const created = await (await expect(201, threads, "POST", owner, form())).json();
const link = new URL(created.shareUrl);
assert.match(link.pathname, /^\/t\/l-/);
assert.equal(created.thread.accessMode, "locked");
assert.equal((await (await expect(200, threads, "POST", owner, form())).json()).shareUrl, created.shareUrl);
await expect(409, threads, "POST", owner, {...payload, accessMode: "wild-west", passkey: undefined});
assert.equal((await (await expect(200, link.pathname)).text()).includes("Private opening"), false);
await expect(404, link.pathname.replace("/l-", "/"));

const api = threads + link.pathname.slice(2);
const post = api + "/posts";
const media = api + "/media/" + created.post.id;
const reply = {operationId: randomUUID(), parentId: created.post.id, body: "Approved reply"};
for (const actor of [null, guest]) {
    for (const route of [api, api + "/history?before=2", api + "/changes?after=0", media]) {
        await expect(403, route, "GET", actor, undefined, {"X-Actor": created.post.authorId, "X-Locked": "false"});
    }
    await expect(403, media, "HEAD", actor);
}
await expect(403, media, "GET", guest, undefined, {Range: "bytes=0-2"});
const refused = await new Promise((resolve, reject) => {
    const transport = origin.protocol === "https:" ? https : http;
    const req = transport.get(new URL(api + "/live", origin), {headers: {
        Cookie: guest, Origin: origin.origin, Upgrade: "websocket", Connection: "Upgrade",
        "Sec-WebSocket-Version": "13", "Sec-WebSocket-Key": "dGhlIHNhbXBsZSBub25jZQ==",
    }}, response => { response.resume(); resolve(response.statusCode); });
    req.on("error", reject);
    req.on("upgrade", (_response, socket) => { socket.destroy(); reject(Error("Guest received a live socket.")); });
    req.setTimeout(10000, () => req.destroy(Error("WebSocket check timed out.")));
});
assert.equal(refused, 403);
await expect(403, post, "POST", guest, reply);
await expect(403, post + "/" + created.post.id, "DELETE", guest);
await expect(403, api + "/requests", "GET", guest);
await expect(404, api + "/handoff", "POST", outsider, {});
await expect(403, api + "/handoff", "POST", await native(), {});
await expect(403, api + "/join", "POST", codeGuest, {passkey: "wrong-passkey"});
await expect(403, api + "/join", "POST", guest, {name: "wrong-origin"}, {Origin: "https://example.com"});

const pending = await (await expect(200, api + "/join", "POST", guest, {name: "Pending guest"})).json();
assert.equal(pending.state, "pending");
await expect(200, api + "/join", "POST", guest, {name: "Retry"});
await expect(200, api + "/join", "POST", denied, {name: "Declined guest"});
await expect(403, api, "GET", guest);
const handoff = await (await expect(200, api + "/handoff", "POST", owner, {})).json();
const token = new URL(handoff.creatorUrl).hash.slice("#creator=".length);
const blockedClaim = await (await expect(409, api + "/claim", "POST", guest, {token})).json();
assert.equal(blockedClaim.error.code, "guest_request_pending");
assert.equal((await (await expect(200, api + "/access", "GET", guest)).json()).state, "pending");
await expect(403, api, "GET", guest);
const manager = await browser();
await expect(200, api + "/claim", "POST", manager, {token});
await expect(403, api + "/claim", "POST", outsider, {token});
const {requests} = await (await expect(200, api + "/requests", "GET", manager)).json();
assert.deepEqual(requests.map(request => request.name).sort(), ["Declined guest", "Pending guest"]);
for (const item of requests) {
    const decision = item.name === "Pending guest" ? "approved" : "declined";
    await expect(200, api + "/requests/" + item.id, "POST", manager, {decision});
    await expect(200, api + "/requests/" + item.id, "POST", manager, {decision});
}
await expect(403, api, "GET", denied);
await expect(403, api + "/join", "POST", denied, {passkey: code});
assert.equal((await (await expect(200, api + "/join", "POST", codeGuest, {passkey: code})).json()).state, "approved");
for (const actor of [guest, codeGuest, manager]) {
    assert.equal((await (await expect(200, api, "GET", actor)).json()).posts[0].body, "Private opening");
    await expect(200, api + "/history?before=2", "GET", actor);
    await expect(200, api + "/changes?after=0", "GET", actor);
    await expect(200, media, "HEAD", actor);
    await expect(206, media, "GET", actor, undefined, {Range: "bytes=0-2"});
}
await expect(403, api, "GET", outsider);
const wording = await (await expect(200, api + "/agreement")).json();
await expect(200, api + "/agreement", "POST", guest, {version: wording.version, license: true, karmicLaw: true});
const published = (await (await expect(201, post, "POST", guest, reply)).json()).post;
await expect(403, post + "/" + published.id, "DELETE", manager);
await expect(200, post + "/" + created.post.id, "DELETE", owner);
const snapshot = await (await expect(200, api, "GET", guest)).json();
assert.equal(snapshot.posts[0].body, null);
assert.equal(snapshot.posts[1].parentId, created.post.id);
await expect(404, media, "GET", guest);
await expect(200, post + "/" + published.id, "DELETE", guest);
console.log("PASS protected reads, range/HEAD, WebSocket, writes, approval, decline, passkey, creator claim, retries, and ownership");
