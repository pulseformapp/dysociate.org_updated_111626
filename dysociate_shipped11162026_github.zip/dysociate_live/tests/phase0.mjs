/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import assert from "node:assert/strict";
import {randomBytes} from "node:crypto";
import {readFile, writeFile} from "node:fs/promises";

const [mode, address, receiptPath] = process.argv.slice(2);
assert.ok((mode === "create" || mode === "restart") && address && receiptPath,
    "Usage: node tests/phase0.mjs <create|restart> <local origin> <receipt path>");
const origin = new URL(address);
assert.ok(origin.protocol === "http:" && origin.hostname === "127.0.0.1",
    "This test creates synthetic data and must use a loopback Worker.");
const fixtures = JSON.parse(await readFile(new URL("../contract/v1.fixtures.json", import.meta.url), "utf-8"));
const operation = () => randomBytes(16).toString("base64url");
const authorization = credential => ({Authorization: "Bearer " + credential});

async function call(path, {method = "GET", body, headers = {}} = {}) {
    const request = {method, headers, signal: AbortSignal.timeout(15000)};
    if (body !== undefined) {
        request.body = JSON.stringify(body);
        request.headers = {"Content-Type": "application/json", ...headers};
    }
    const response = await fetch(new URL(path, origin), request);
    const type = response.headers.get("Content-Type") || "";
    const value = type.startsWith("application/json") ? await response.json() : await response.text();
    return {status: response.status, headers: response.headers, value};
}

const create = (body, headers) => call("/api/v1/threads", {method: "POST", body, headers});
const session = (client, headers) => call("/api/v1/session", {method: "POST", body: {client}, headers});
const apiPath = result => "/api/v1/threads/" + new URL(result.shareUrl).pathname.slice(3);

async function verifyThread(result, credential) {
    assert.equal(new URL(result.shareUrl).origin, origin.origin);
    const guest = await call(apiPath(result));
    assert.equal(guest.status, 200);
    assert.equal(guest.headers.get("Cache-Control"), "private, no-store");
    const {media, ...snapshot} = guest.value;
    if (media !== undefined) {
        assert.equal(media.photos, true);
        assert.equal(typeof media.reels, "boolean");
    }
    assert.deepEqual(snapshot, {
        thread: result.thread, posts: [result.post], headSeq: 1, olderCursor: null, viewerAuthorId: null,
    });

    const author = await call(apiPath(result), {headers: authorization(credential)});
    assert.equal(author.status, 200);
    assert.equal(author.value.viewerAuthorId, result.post.authorId);
    const page = await call(new URL(result.shareUrl).pathname);
    assert.equal(page.status, 200);
    assert.equal(page.headers.get("Referrer-Policy"), "no-referrer");
    assert.match(page.headers.get("Content-Security-Policy"), /script-src 'self'/);
    assert.ok(!page.value.includes(result.post.body), "Post text stays out of the link-preview shell.");
    assert.match(page.value, /\/t\/_assets\/thread-page\.js/);
}

if (mode === "create") {
    assert.equal((await call("/api/v1/health")).status, 204);
    const body = {
        ...fixtures.createRequest,
        operationId: operation(),
        openingPost: {...fixtures.createRequest.openingPost, body: "Hello λ <script>never execute this</script>"},
    };
    assert.equal((await create(body)).status, 401);
    assert.equal((await session("browser", {Origin: "https://elsewhere.example"})).status, 403);
    const browser = await session("browser", {Origin: origin.origin});
    assert.equal(browser.status, 200);
    const setCookie = browser.headers.get("Set-Cookie");
    assert.ok(setCookie?.includes("HttpOnly; SameSite=Strict"));
    if (setCookie.startsWith("dysociate-live-loopback=")) {
        assert.equal(origin.origin, "http://127.0.0.1:8795");
    } else {
        assert.match(setCookie, /^__Host-dysociate-live=.*; Secure;/);
    }
    const cookie = setCookie.split(";", 1)[0];
    const renewed = await session("browser", {Origin: origin.origin, Cookie: cookie});
    assert.ok(renewed.headers.get("Set-Cookie")?.startsWith(cookie + ";"), "Browser identity survives renewal.");
    assert.equal((await create(body, {Cookie: cookie, Origin: "https://elsewhere.example"})).status, 403);

    const native = await session("native");
    assert.equal(native.status, 201);
    const {credential} = native.value;
    assert.ok(/^[A-Za-z0-9_-]{43}$/.test(credential), "The native credential has 256 bits.");
    const headers = authorization(credential);
    const large = {...body, openingPost: {body: "λ".repeat(2049)}};
    assert.equal((await create(large, headers)).status, 400);
    assert.equal((await create({...body, unexpected: true}, headers)).status, 400);
    assert.equal((await create({...body, title: "x".repeat(33000)}, headers)).status, 413);

    const duplicate = await Promise.all([create(body, headers), create(body, headers)]);
    assert.deepEqual(duplicate.map(result => result.status).sort(), [200, 201]);
    const result = duplicate.find(value => value.status === 201).value;
    assert.deepEqual(duplicate[0].value, duplicate[1].value);
    assert.equal(result.headSeq, 1);
    assert.equal(result.post.body, body.openingPost.body);
    assert.equal(result.post.parentId, null);
    assert.equal(result.post.deletedAt, null);
    assert.equal(result.post.createdSeq, result.post.updatedSeq);
    assert.equal((await create({...body, title: "A different title"}, headers)).value.error.code, "operation_conflict");

    await verifyThread(result, credential);
    const otherViewer = await call(apiPath(result), {headers: {Cookie: cookie}});
    assert.notEqual(otherViewer.value.viewerAuthorId, result.post.authorId);
    const anotherThread = await create({...body, operationId: operation()}, headers);
    assert.equal(anotherThread.status, 201);
    assert.notEqual(anotherThread.value.post.authorId, result.post.authorId);

    const [version, room, tag] = new URL(result.shareUrl).pathname.slice(3).split(".");
    const tampered = version + "." + room + "." + (tag[0] === "A" ? "B" : "A") + tag.slice(1);
    assert.deepEqual((await call("/api/v1/threads/" + tampered)).value, fixtures.error);
    assert.equal((await call("/t/" + tampered)).status, 404);

    await writeFile(receiptPath, JSON.stringify({credential, body, result}), {flag: "wx"});
    console.log("PASS create, read, concurrent retry, anonymous ownership, request limits, signed invite, browser shell");
} else {
    const {credential, body, result} = JSON.parse(await readFile(receiptPath, "utf-8"));
    await verifyThread(result, credential);
    const retry = await create(body, authorization(credential));
    assert.equal(retry.status, 200);
    assert.deepEqual(retry.value, result);
    console.log("PASS after restart: same link, opening post, ownership, and create receipt");
}
