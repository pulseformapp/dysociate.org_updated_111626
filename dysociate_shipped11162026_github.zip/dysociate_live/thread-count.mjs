/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

export function threadCounter(env) {
    return env.THREAD_COUNT.get(env.THREAD_COUNT.idFromName("live-threads"));
}

export class ThreadCount {
    constructor(state) {
        this.storage = state.storage;
        this.sql = this.storage.sql;
        this.sql.exec(`CREATE TABLE IF NOT EXISTS counted_threads (id TEXT PRIMARY KEY) WITHOUT ROWID;
            CREATE TABLE IF NOT EXISTS total (singleton INTEGER PRIMARY KEY, value INTEGER NOT NULL);
            INSERT OR IGNORE INTO total VALUES (1, 0);`);
    }

    async fetch(request) {
        if (request.method === "GET") {
            return Response.json({liveThreadsCreated: this.sql.exec("SELECT value FROM total WHERE singleton = 1").one().value});
        }
        if (request.method !== "POST") return new Response(null, {status: 405});
        const ids = await request.json();
        if (!Array.isArray(ids) || ids.length > 100 || ids.some(id => typeof id !== "string" || !/^[0-9a-f]{64}$/.test(id)))
            return new Response(null, {status: 400});

        // The Durable Object ID is the receipt. Creation retries and the
        // historical import share it, so each committed thread counts once.
        this.storage.transactionSync(() => {
            let added = 0;
            for (const id of ids) {
                added += this.sql.exec("INSERT OR IGNORE INTO counted_threads VALUES (?) RETURNING id", id).toArray().length;
            }
            if (added) this.sql.exec("UPDATE total SET value = value + ? WHERE singleton = 1", added);
        });
        return new Response(null, {status: 204});
    }
}
