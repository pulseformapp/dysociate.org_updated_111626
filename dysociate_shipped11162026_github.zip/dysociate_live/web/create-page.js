/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
import {browserSession, request} from "./thread-client.js";
import {reviewAgreements} from "./agreements.js";

const byId = id => document.getElementById(id);
const form = byId("create-thread");
const fields = byId("thread-fields");
const title = byId("thread-title");
const body = byId("opening-post");
const name = byId("creator-name");
const locked = byId("locked");
const passkey = byId("passkey");
const status = byId("create-status");
const submit = byId("create-submit");
const result = byId("creation-result");
const link = byId("thread-link");
const startOver = byId("start-over");
const storageKey = "dysociate-live-create";
const encoder = new TextEncoder();
let pending, busy = false;
const agreementsEndpoint = "/api/v1/agreements";
const retryAgreements = byId("review-agreements");

function updateMode() {
    byId("passkey-options").hidden = !locked.checked;
    byId("access-note").textContent = locked.checked
        ? "Guests can request access. You approve them from this browser."
        : "Anyone with the link can read and reply.";
}

function draft() {
    return {title: title.value, body: body.value, name: name.value, locked: locked.checked};
}

function persist() {
    try { sessionStorage.setItem(storageKey, JSON.stringify({draft: draft(), pending})); }
    catch { /* The current tab retains a usable draft without browser storage. */ }
}

function restore() {
    try {
        const saved = JSON.parse(sessionStorage.getItem(storageKey) || "{}");
        title.value = saved.draft?.title || "";
        body.value = saved.draft?.body || "";
        name.value = saved.draft?.name || "";
        locked.checked = saved.draft?.locked === true;
        if (/^[a-z0-9-]{36}$/.test(saved.pending?.id) && typeof saved.pending.identity === "string") {
            pending = saved.pending;
            if (pending.hasPasskey) status.textContent = "Re-enter your passkey to retry the same creation.";
        }
    } catch { /* Start with an empty draft if the saved data is unavailable. */ }
}

async function signature({passkey: _passkey, ...payload}, identity) {
    // The local receipt stores no password verifier. The server checks
    // whether a re-entered passkey matches the original committed request.
    const data = encoder.encode(identity + "\n" + JSON.stringify({...payload, usesPasskey: Boolean(_passkey)}));
    return [...new Uint8Array(await crypto.subtle.digest("SHA-256", data))]
        .map(value => value.toString(16).padStart(2, "0")).join("");
}

function reset() {
    form.reset();
    form.hidden = false;
    result.hidden = startOver.hidden = true;
    pending = undefined;
    submit.textContent = "Create live thread";
    status.textContent = "";
    persist();
    updateMode();
    title.focus();
}

function success(address) {
    const created = new URL(address, location.origin);
    if (created.origin !== location.origin || !/^\/t\/(?:l-)?[a-z0-9]{1,12}\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}$/.test(created.pathname) ||
        created.search || created.hash || created.username || created.password) throw Error("The service returned an invalid thread link.");
    link.value = created.href;
    byId("open-thread").href = created.href;
    passkey.value = "";
    result.hidden = false;
    form.hidden = true;
    pending.link = created.href;
    persist();
    status.textContent = "Thread created.";
    byId("open-thread").focus();
}

form.addEventListener("input", () => {
    updateMode();
    persist();
});
form.addEventListener("submit", async event => {
    event.preventDefault();
    if (busy) return;
    const values = draft();
    const code = values.locked ? passkey.value.trim() : "";
    if (pending?.hasPasskey && !code) {
        status.textContent = "Re-enter your passkey to retry. Use Start a new draft to begin again.";
        return;
    }
    if (!values.title.trim() || !values.body.trim() || encoder.encode(values.body.trim()).length > 4096 ||
        (code && (code.length < 8 || encoder.encode(code).length > 128))) {
        status.textContent = "Enter a title and a post up to 4,096 UTF-8 bytes. A passkey needs at least 8 characters and fits in 128 bytes.";
        return;
    }
    const payload = {
        title: values.title.trim(),
        openingPost: {body: values.body.trim(), displayName: values.name.trim() || "Guest"},
        accessMode: values.locked ? "locked" : "wild-west",
        ...(code ? {passkey: code} : {}),
    };
    busy = fields.disabled = startOver.disabled = true;
    status.textContent = "Creating your thread…";
    try {
        const {identity} = await browserSession(true);
        if (typeof identity !== "string") throw Error("This browser could not start a creation session.");
        const fingerprint = await signature(payload, identity);
        if (pending && (identity !== pending.identity || fingerprint !== pending.fingerprint)) {
            throw Error("Your browser session or draft changed since the previous attempt. Restore the original draft or start a new one.");
        }
        pending ||= {id: crypto.randomUUID(), identity, fingerprint, hasPasskey: Boolean(code)};
        persist();
        const created = await request("/api/v1/threads", "POST", {...payload, operationId: pending.id});
        success(created.shareUrl);
    } catch (error) {
        // An error after a successful server commit must reuse the same
        // operation ID so retrying does not create an extra thread.
        if (["invalid_input", "locked_disabled", "browser_create_disabled"].includes(error.code)) {
            pending = undefined;
            persist();
        }
        if (error.code === "agreements_required") {
            form.hidden = true;
            retryAgreements.hidden = false;
        }
        status.textContent = error.message;
        startOver.hidden = !pending;
        submit.textContent = pending ? "Retry creation" : "Create live thread";
    } finally {
        busy = fields.disabled = startOver.disabled = false;
    }
});

byId("copy-thread").addEventListener("click", async () => {
    try {
        await navigator.clipboard.writeText(link.value);
        status.textContent = "Link copied.";
    } catch {
        link.focus();
        link.select();
        status.textContent = "Copy the selected link.";
    }
});
startOver.addEventListener("click", reset);
byId("another-thread").addEventListener("click", reset);
status.textContent = "";
restore();
byId("locked-options").hidden = document.documentElement.dataset.locked !== "on";
if (byId("locked-options").hidden) locked.checked = false;
updateMode();

async function openEditor() {
    retryAgreements.hidden = true;
    try {
        await browserSession(true);
        const terms = await request(agreementsEndpoint);
        if (terms.required && !terms.accepted && !await reviewAgreements(agreementsEndpoint, terms)) {
            location.assign("/");
            return;
        }
        if (!pending?.hasPasskey) status.textContent = "";
        form.hidden = false;
        if (pending?.link) {
            try { success(pending.link); } catch { reset(); }
        } else if (pending) {
            startOver.hidden = false;
            submit.textContent = "Retry creation";
        }
    } catch (error) {
        status.textContent = error.message;
        retryAgreements.hidden = false;
    }
}

retryAgreements.addEventListener("click", openEditor);
void openEditor();
