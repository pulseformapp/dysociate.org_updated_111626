/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

export async function request(path, method = "GET", payload) {
    const controller = new AbortController();
    const options = {method, cache: "no-store", signal: controller.signal};
    if (payload instanceof FormData) {
        options.body = payload;
    } else if (payload !== undefined) {
        options.headers = {"Content-Type": "application/json"};
        options.body = JSON.stringify(payload);
    }
    const timeout = setTimeout(() => controller.abort(), payload instanceof FormData ? 45000 : 12000);
    try {
        let response;
        try { response = await fetch(path, options); }
        catch { throw Error("Could not reach the thread. Try again."); }
        const body = await response.json().catch(() => null);
        if (!response.ok || !body) {
            const failure = Error(body?.error?.message || "The thread service is unavailable.");
            failure.code = body?.error?.code;
            throw failure;
        }
        return body;
    } finally {
        clearTimeout(timeout);
    }
}

export function browserSession(creation = false) {
    const start = () => request("/api/v1/session", "POST", {client: "browser", ...(creation ? {creation} : {})});
    // Two fresh tabs must not issue separate first-use identity cookies.
    return navigator.locks ? navigator.locks.request("dysociate-browser-session", start) : start();
}

export function withAttachment(payload, media) {
    if (!media) return payload;
    const form = new FormData();
    form.set("payload", JSON.stringify(payload));
    form.set("media", media);
    return form;
}

export class ThreadClient {
    constructor(invite, origin, onChange) {
        this.origin = origin;
        this.api = "/api/v1/threads/" + invite;
        this.onChange = onChange;
        this.status = "Connecting…";
        this.thread = null;
        this.posts = new Map();
        this.rootCounts = new Map();
        this.reactions = new Map();
        this.cursor = 0;
        this.olderCursor = null;
        this.viewerAuthorId = null;
        this.media = null;
        this.socket = null;
        this.queue = [];
        this.draining = false;
        this.retryDelay = 350;
        this.retryTimer = null;
        this.readyTimer = null;
        this.access = null;
    }

    request = request;

    async start(creatorToken) {
        this.setStatus("Connecting…");
        await browserSession();
        if (creatorToken) {
            try { await this.request(this.api + "/claim", "POST", {token: creatorToken}); }
            catch (error) {
                this.claimError = error.message;
            }
        }
        if (this.api.split("/").at(-1).startsWith("l-")) {
            await this.checkAccess();
        } else {
            await this.openThread();
        }
    }

    async checkAccess() {
        if (this.thread) return;
        if (this.checkingAccess) return this.checkingAccess;
        this.checkingAccess = this.loadAccess();
        try {
            await this.checkingAccess;
        } finally {
            this.checkingAccess = null;
        }
    }

    async loadAccess() {
        this.access = await this.request(this.api + "/access");
        if (this.access.state === "approved") await this.openThread();
        else this.setStatus("Locked thread");
    }

    async join(payload) {
        await this.request(this.api + "/join", "POST", payload);
        if (this.checkingAccess) await this.checkingAccess.catch(() => {});
        await this.checkAccess();
    }

    async openThread() {
        const snapshot = await this.request(this.api + "?view=groups");
        this.thread = snapshot.thread;
        this.viewerAuthorId = snapshot.viewerAuthorId;
        this.media = snapshot.media;
        this.pushKey = snapshot.pushKey;
        this.agreementsRequired = snapshot.agreementsRequired;
        this.agreementAccepted = snapshot.agreementAccepted;
        this.olderCursor = snapshot.olderCursor;
        this.cursor = snapshot.headSeq;
        this.merge(snapshot.posts);
        this.onChange();
        this.connect();
    }

    setStatus(status) {
        this.status = status;
        this.onChange();
    }

    merge(posts) {
        for (const post of posts) {
            const rootId = post.rootId || post.id;
            // Reply markers remain in the branch after deletion, so these
            // counts only increase even when older page responses arrive late.
            this.rootCounts.set(rootId, Math.max(this.rootCounts.get(rootId) || 0, post.rootReplyCount || 0));
            const current = this.posts.get(post.id);
            if (!current || current.updatedSeq < post.updatedSeq) this.posts.set(post.id, post);
        }
    }

    visibleRoots() {
        return [...this.posts.values()]
            .filter(post => !post.parentId)
            .sort((left, right) => left.createdSeq - right.createdSeq);
    }

    async loadOlder() {
        if (this.olderCursor === null) return;
        const page = await this.request(this.api + "/history?view=groups&before=" + this.olderCursor);
        this.merge(page.posts);
        this.olderCursor = page.olderCursor;
        this.onChange();
    }

    async loadBranch(rootId, after) {
        const page = await this.request(this.api + "/branch/" + rootId + "?after=" + after);
        this.merge([page.root, ...page.posts]);
        return page;
    }

    async loadTarget(postId) {
        const target = await this.request(this.api + "/target/" + postId);
        this.merge([target.root, target.post]);
        return target;
    }

    mergeReactions(values) {
        for (const value of values) {
            const previous = this.reactions.get(value.postId);
            if (!previous || value.revision >= previous.revision) this.reactions.set(value.postId, value);
        }
    }

    async loadReactions(ids) {
        for (let start = 0; start < ids.length; start += 50) {
            const {reactions} = await this.request(this.api + "/reactions?ids=" + ids.slice(start, start + 50).join(","));
            this.mergeReactions(reactions);
        }
    }

    async like(postId, command) {
        const result = await this.request(this.api + "/like/" + postId, "PUT", command);
        this.mergeReactions([result]);
    }

    async post(payload, media) {
        const result = await this.request(this.api + "/posts?view=groups", "POST", withAttachment(payload, media));
        this.merge([result.post]);
        // An acknowledgment can arrive before an earlier event from someone
        // else. Only the live stream or catch-up advances the shared cursor.
        this.onChange();
        return result.post;
    }

    async delete(postId) {
        const result = await this.request(this.api + "/posts/" + postId + "?view=groups", "DELETE");
        this.merge([result.post]);
        this.onChange();
    }

    connect() {
        if (this.socket || !this.thread) return;
        clearTimeout(this.retryTimer);
        const address = new URL(this.api + "/live?view=groups", this.origin);
        address.protocol = address.protocol === "https:" ? "wss:" : "ws:";
        const socket = new WebSocket(address);
        this.socket = socket;
        this.readyTimer = setTimeout(() => this.disconnect(socket), 10000);
        socket.onmessage = event => {
            if (this.socket !== socket) return;
            let message;
            try { message = JSON.parse(event.data); }
            catch { this.disconnect(socket); return; }
            if (message.type === "ready") clearTimeout(this.readyTimer);
            this.enqueue(socket, message);
        };
        socket.onerror = () => this.disconnect(socket);
        socket.onclose = () => this.disconnect(socket);
    }

    disconnect(socket) {
        if (this.socket !== socket) return;
        clearTimeout(this.readyTimer);
        this.socket = null;
        this.queue = [];
        if (socket.readyState < WebSocket.CLOSING) socket.close();
        this.setStatus("Reconnecting…");
        this.retryTimer = setTimeout(() => this.connect(), this.retryDelay + Math.random() * 250);
        this.retryDelay = Math.min(this.retryDelay * 2, 8000);
    }

    resume() {
        if (!this.socket) this.connect();
        else if (this.socket.readyState === WebSocket.OPEN) this.enqueue(this.socket, {type: "resume"});
    }

    enqueue(socket, message) {
        if (this.queue.length >= 1000) {
            this.disconnect(socket);
            return;
        }
        this.queue.push({socket, message});
        if (!this.draining) void this.drain();
    }

    async catchUp(socket) {
        let hasMore;
        do {
            const result = await this.request(this.api + "/changes?view=groups&after=" + this.cursor);
            if (this.socket !== socket) return;
            if (result.nextAfter < this.cursor || (result.hasMore && result.nextAfter === this.cursor)) {
                throw Error("Could not catch up with the thread.");
            }
            this.merge(result.posts);
            this.cursor = result.nextAfter;
            hasMore = result.hasMore;
        } while (hasMore);
        this.onChange();
    }

    async drain() {
        this.draining = true;
        while (this.queue.length) {
            const {socket, message} = this.queue.shift();
            if (this.socket !== socket) continue;
            try {
                if (message.type === "ready" || message.type === "resume") {
                    if (message.type === "resume" || message.headSeq > this.cursor) await this.catchUp(socket);
                    if (this.socket !== socket) continue;
                    this.retryDelay = 350;
                    this.setStatus("Live");
                    this.onChange("reaction-refresh");
                    if (this.access?.role === "creator") this.onChange("requests");
                } else if (message.type === "reaction.changed") {
                    this.onChange(message);
                } else if (message.type === "access.requests" && this.access?.role === "creator") {
                    this.onChange("requests");
                } else if (message.type === "post.changed" && message.seq > this.cursor) {
                    if (message.seq !== this.cursor + 1) await this.catchUp(socket);
                    if (this.socket !== socket || message.seq <= this.cursor) continue;
                    if (message.seq !== this.cursor + 1) throw Error("Missing thread changes.");
                    this.merge([message.post]);
                    this.cursor = message.seq;
                    this.onChange();
                }
            } catch {
                this.disconnect(socket);
            }
        }
        this.draining = false;
    }
}
