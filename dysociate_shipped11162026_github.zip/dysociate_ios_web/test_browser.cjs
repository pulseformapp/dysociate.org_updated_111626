// Copyright (c) 2026 Luna Love ~ LunaSoft
// SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
// A private headless Edge profile exercises real IndexedDB and service workers.
// Phone widths emulate layout, not Safari/iOS. Only share-sheet/file-picker
// boundaries are substituted; no message is sent and no user profile is opened.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const root=path.resolve(__dirname,'../../work/ios-qa');fs.mkdirSync(root,{recursive:true});
const address=process.argv[2] || 'http://127.0.0.1:8766/';
const pause=ms=>new Promise(r=>setTimeout(r,ms));
function connect(address){return new Promise((resolve,reject)=>{
 const socket=new WebSocket(address),pending=new Map();let sequence=0;
 socket.addEventListener('open',()=>resolve({socket,call(method,params={}){const id=++sequence;return new Promise((ok,fail)=>{pending.set(id,[ok,fail]);socket.send(JSON.stringify({id,method,params}));});}}));
 socket.addEventListener('error',reject);
 socket.addEventListener('message',event=>{const item=JSON.parse(event.data);if(pending.has(item.id)){const [ok,fail]=pending.get(item.id);pending.delete(item.id);item.error?fail(Error(JSON.stringify(item.error))):ok(item.result);}});
});}
const bootstrap=`window.__errors=[];window.addEventListener('error',e=>__errors.push(e.message));window.addEventListener('unhandledrejection',e=>__errors.push(String(e.reason)));
window.confirm=()=>true;window.__shares=[];window.__canShare=true;window.__cancelShare=false;
Object.defineProperty(navigator,'canShare',{value:()=>window.__canShare,configurable:true});
Object.defineProperty(navigator,'share',{value:options=>{window.__shares.push(options);return window.__cancelShare?Promise.reject(new DOMException('Canceled','AbortError')):Promise.resolve();},configurable:true});
let adapter;Object.defineProperty(window,'DysociateAndroid',{get:()=>adapter,set:value=>{adapter=value;const start=value.start;value.start=api=>{window.__editor=api;return start(api);};}});`;
(async()=>{
 for(const width of [320,390,820,1280]){
  const profile=fs.mkdtempSync(path.join(root,'profile-'+width+'-'));
  const child=spawn('C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',[
   '--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-sync',
   '--remote-debugging-port=0','--remote-debugging-address=127.0.0.1','--user-data-dir='+profile,'about:blank'],{windowsHide:true,stdio:'ignore'});
  let browser,tab;
  try{
   const marker=path.join(profile,'DevToolsActivePort');
   for(let i=0;i<300&&!fs.existsSync(marker);i++)await pause(30);
   const [port,endpoint]=fs.readFileSync(marker,'utf8').trim().split('\n');
   browser=await connect('ws://127.0.0.1:'+port+endpoint.trim());
   const target=await(await fetch('http://127.0.0.1:'+port+'/json/new?about:blank',{method:'PUT'})).json();
   tab=await connect(target.webSocketDebuggerUrl);await tab.call('Page.enable');
   await tab.call('Emulation.setDeviceMetricsOverride',{width,height:900,deviceScaleFactor:1,mobile:width<600});
   await tab.call('Page.addScriptToEvaluateOnNewDocument',{source:bootstrap});
   async function run(expression){const r=await tab.call('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;}
   async function until(expression){for(let i=0;i<200;i++){if(await run(expression))return;await pause(30);}throw Error('Timed out: '+expression);}
   const click=id=>run(`document.getElementById(${JSON.stringify(id)}).click()`);
   const text=id=>run(`document.getElementById(${JSON.stringify(id)}).textContent`);
   const set=(id,value)=>run(`(()=>{const n=document.getElementById(${JSON.stringify(id)});n.value=${JSON.stringify(value)};n.dispatchEvent(new Event('input',{bubbles:true}));})()`);
   async function screenshot(name){const shot=await tab.call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});fs.writeFileSync(path.join(root,name+'-'+width+'.png'),Buffer.from(shot.data,'base64'));}
   await tab.call('Page.navigate',{url:address});
   await until(`document.getElementById('iphone-agreement')?.open`);
   assert.equal(await run(`document.querySelector('main').inert`),true);
   assert.equal(await run(`document.getElementById('iphone-agree').hidden`),true,'Agree revealed before reading');
   await screenshot('license');
   await click('iphone-disagree');assert.equal(await run(`document.querySelector('main').hidden`),true,'Decline did not lock');
   await click('iphone-review');
   await run(`(()=>{const n=document.getElementById('iphone-agreement-text');n.scrollTop=n.scrollHeight;n.dispatchEvent(new Event('scroll'));})()`);
   await click('iphone-agree');await until(`!document.getElementById('iphone-agree').hidden`);
   assert.equal(await text('iphone-agreement-title'),'Karmic Law');
   assert.ok((await text('iphone-agreement-text')).includes('~ as above so below ~'));
   await screenshot('karmic');await click('iphone-agree');
   assert.equal(await run(`document.querySelector('main').inert`),false);
   await until(`document.getElementById('iphone-offline').textContent.startsWith('Ready offline')`);
   const pixel='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aY1UAAAAASUVORK5CYII=';
   await run(`__editor.loadImage(new File([Uint8Array.from(atob('${pixel}'),c=>c.charCodeAt(0))],'phone.png',{type:'image/png'}))`);
   await set('comment-body','Luna <3 '+ 'w'.repeat(1200));
   await run(`document.getElementById('comment-form').requestSubmit()`);
   await run(`document.querySelector('[data-reply-to]').click()`);
   await set('comment-body','Reply from iPhone edition');
   await run(`document.getElementById('comment-form').requestSubmit()`);
   await set('comment-body','Unfinished recovered draft');
   await run(`DysociateAndroid.state(false,false,true,true)`);await pause(900);
   await tab.call('Page.reload',{});
   await until(`window.__editor && document.getElementById('comment-body').value === 'Unfinished recovered draft'`);
   assert.equal(await run(`document.querySelectorAll('.thread-item').length`),2);
   assert.equal(await run(`document.getElementById('iphone-agreement').open`),false,'Agreements forgotten');
   // Save commits the draft but only prepares a file. Download/share completion
   // is not a claim that Safari overwrote the source attachment.
   await click('save-html');await until(`!document.getElementById('iphone-file-ready').hidden`);
   const exported=await run(`fetch(document.getElementById('iphone-download').href).then(r=>r.text())`);
   fs.writeFileSync(path.join(root,'export-'+width+'.html'),exported);
   assert.ok(!exported.includes('data-ios')&&!exported.includes('iphone.js')&&!exported.includes('sw.js'),'Installed shell leaked into export');
   assert.ok(exported.includes('Unfinished recovered draft')&&exported.includes('GNU GENERAL PUBLIC LICENSE'));
   assert.ok(exported.includes('data:image/png;base64,'+pixel),'Selected image missing from export');
   const invalid='<script id="luna-page-data" type="application/json">{"sections":[{"post_id":"x","parent_id":"x"}]}<\/script><script>window.__importRan=true<\/script>';
   await run(`__editor.openThread(new File([${JSON.stringify(invalid)}],'bad.html',{type:'text/html'}))`);
   assert.equal(await run(`document.querySelectorAll('.thread-item').length`),3,'Bad import destroyed thread');
   assert.ok(!(await run(`window.__importRan`)),'Imported script executed');
   await run(`window.__cancelShare=true`);await click('iphone-share-html');
   await until(`document.getElementById('iphone-feedback').textContent.includes('canceled')`);
   assert.equal(await run(`__editor.checkpoint().changed`),true,'Canceled share marked work saved');
   await run(`window.__cancelShare=false;window.__canShare=false`);await click('iphone-share-html');
   await until(`document.getElementById('iphone-feedback').textContent.includes('Download file')`);
   await run(`window.__canShare=true`);await click('iphone-share-ready');
   await until(`document.getElementById('iphone-feedback').textContent.includes('handed')`);
   assert.equal(await run(`window.__shares.at(-1).files[0].name`),'index.html');
   assert.equal(await run(`document.querySelector(".iphone-tools a[href$='/t/new']").href`),
       'https://dysociate.org/t/new');
   await click('share-email');await until(`document.getElementById('iphone-file-name').textContent.startsWith('dysociate-email.eml')`);
   const mime=await run(`fetch(document.getElementById('iphone-download').href).then(r=>r.text())`);
   assert.ok(mime.includes('Content-Disposition: attachment; filename="index.html"'),'Email lacks attachment');
   fs.writeFileSync(path.join(root,'email-'+width+'.eml'),mime);
   await click('iphone-help');assert.equal(await run(`document.getElementById('iphone-help-dialog').open`),true);await screenshot('help');await click('iphone-help-close');
   const metrics=await run(`({overflow:document.documentElement.scrollWidth>innerWidth+1, font:parseFloat(getComputedStyle(document.getElementById('comment-body')).fontSize),buttons:[...document.querySelectorAll('button')].filter(n=>n.getBoundingClientRect().width>0).every(n=>n.getBoundingClientRect().height>=44),errors:__errors})`);
   assert.equal(metrics.overflow,false,'Horizontal overflow');assert.ok(metrics.font>=16&&metrics.buttons,'Phone targets/font too small');assert.deepEqual(metrics.errors,[]);
   await run(`window.scrollTo(0,0)`);await screenshot('editor');
   // A quota/transaction failure must warn, retain the thread and allow export.
   await run(`window.__transaction=IDBDatabase.prototype.transaction;IDBDatabase.prototype.transaction=function(...args){if(args[1]==='readwrite')throw new DOMException('Full','QuotaExceededError');return __transaction.apply(this,args);}`);
   await set('comment-title','Storage test');
   await until(`document.getElementById('iphone-feedback').textContent.includes('could not be saved')`);
   assert.equal(await run(`document.querySelectorAll('.thread-item').length`),3);
   await run(`IDBDatabase.prototype.transaction=window.__transaction`);
   await set('comment-title','');await pause(900);
   // Actual browser network isolation, not navigator.onLine stubbing. The
   // service worker must serve navigation and the recovery database must open.
   await tab.call('Network.enable');await tab.call('Network.emulateNetworkConditions',{offline:true,latency:0,downloadThroughput:0,uploadThroughput:0});
   await tab.call('Page.navigate',{url:address+'?offline-check'});
   await until(`window.__editor && document.querySelectorAll('.thread-item').length===3 && !document.querySelector('main').inert`);
   assert.equal(await run(`navigator.onLine`),false);
   assert.equal(await run(`__editor.checkpoint().page.sections[0].image_data_url`),'data:image/png;base64,'+pixel);
   // Produce a real empty portable export for the shared regression suite.
   await click('new-thread');await click('save-html');
   await until(`!document.getElementById('iphone-file-ready').hidden`);
   fs.writeFileSync(path.join(root,'empty-export-'+width+'.html'),await run(`fetch(document.getElementById('iphone-download').href).then(r=>r.text())`));
   const report={width,agreements:true,recovery:true,export:true,invalidImport:true,shareCancel:true,shareFallback:true,emailAttachment:true,offlineReload:true,metrics};
   fs.writeFileSync(path.join(root,'result-'+width+'.json'),JSON.stringify(report,null,2));console.log('PASS',JSON.stringify(report));
  }finally{
   if(tab)tab.socket.close();
   if(browser){await browser.call('Browser.close').catch(()=>{});browser.socket.close();}else child.kill();
  }
 }
 console.log('PASS: 4 responsive widths; real recovery, offline navigation, portable export, email attachment and share failure boundaries. Safari/device testing remains separate.');
})().catch(error=>{console.error(error);process.exitCode=1;});
