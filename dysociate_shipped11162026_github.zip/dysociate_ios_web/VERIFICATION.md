# Verification — 1.5.6-ios-web.1

Performed on Windows with a private headless Edge profile. These checks do not
constitute iPhone/Safari or App Store certification.

- Passed at 320, 390, 820 and 1280 CSS pixels: no horizontal overflow, at least
  44 px visible button targets, 16 px editor fields, no uncaught JS errors.
- License scroll gate, decline lock, review/reacceptance, Karmic Law signoff.
- Post, image, nested reply, unfinished draft recovery after a browser reload.
- Simulated storage quota failure warns while retaining the current thread.
- Selected PNG survives export and recovery after offline navigation.
- Malformed import keeps the original thread; imported scripts do not execute.
- Mocked share-sheet cancellation retains changed state. Unsupported file
  sharing offers a downloadable file. Successful handoff does not claim delivery.
- Actual service worker serves a fresh navigation with browser networking
  disabled. Recovery database opens in that offline session.
- Four .eml exports independently parsed by Python's email parser: one HTML
  attachment each, with the latest text and photo, and no installed-app assets.
- Actual empty HTML exported by the app passed all 13 canonical browser
  regression scenarios, including reply/edit/delete, deep trees, image handling,
  save cancellation/failure, mail-size limits and cancellation.
- Extracted release source reproduced all nine deployed files byte for byte.
- Release ZIP CRCs and SHA-256 checksums verified.

Not performed: real iPhone/iPad Safari, phone share destinations, physical file
picker UI, real-world storage pressure, OS eviction, multiple-device exchange,
or a deployed service-worker upgrade on iOS. See TESTING.md before release.

The owner authorized source upload and an owner-private HTTPS preview after
these local checks. Deployment status is verified separately by the Sites
publication workflow. This preview does not constitute a public iOS release.
