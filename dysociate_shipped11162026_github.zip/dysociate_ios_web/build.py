"""Build the iPhone/iPad app from dλsociate's canonical portable editor.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

Only the installed shell gets an adapter, manifest and service worker. Exported
threads strip these additions and keep the same self-contained editor used by
Windows and Android. No server receives the user's HTML or pictures.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys
from urllib.parse import urlsplit

from PIL import Image

HERE = Path(__file__).resolve().parent
VERSION = "1.9.0-ios-web.1"


def build(shared: Path, destination: Path, live_editor: str = "https://dysociate.org/t/new"):
    target = urlsplit(live_editor)
    if target.scheme != "https" or not target.hostname or target.username or target.password or target.path != "/t/new" or target.query or target.fragment:
        raise ValueError("Use an HTTPS live editor URL ending in /t/new.")
    sys.path.insert(0, str(shared.resolve()))
    from app_resources import KARMIC_LAW, KARMIC_SIGNOFF
    from pagebuilder_gui import Page, render_document

    destination.mkdir(parents=True, exist_ok=True)
    document = render_document(Page(title="Untitled thread"))
    license_body = (shared / "LICENSE").read_text(encoding="utf-8")
    terms_version = hashlib.sha256((license_body + KARMIC_LAW + KARMIC_SIGNOFF).encode()).hexdigest()
    metadata = '''
<meta data-ios-only name="theme-color" content="#0c0714">
<meta data-ios-only name="apple-mobile-web-app-capable" content="yes">
<meta data-ios-only name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta data-ios-only name="apple-mobile-web-app-title" content="dλsociate">
<meta data-ios-only name="description" content="Your threads. Your device. Offline HTML conversations.">
<link data-ios-only rel="manifest" href="./manifest.webmanifest">
<link data-ios-only rel="apple-touch-icon" href="./icon-180.png">
<link data-ios-only rel="icon" href="./icon-192.png">
<link data-ios-only rel="stylesheet" href="./iphone.css">
'''
    brand = '''<div data-ios-only class="iphone-brand">
<p class="iphone-slogan">~ the original off grid clandestine social network xD welcome to the outernet ~</p>
<div class="iphone-identity"><img src="./icon-192.png" alt="" width="56" height="56">
<div><strong>dλsociate</strong><p>OFFLINE THREADS / ONE HTML FILE / AI is kill /<br>created by luna love, lunasoft λ 2026</p></div></div>
<p id="iphone-offline" role="status">Preparing offline access…</p>
<p id="iphone-feedback" role="status" hidden></p>
</div>'''
    from html import escape
    controls = f'''<div data-ios-only class="iphone-tools">
<a class="file-button" id="iphone-live" href="{escape(live_editor, quote=True)}" target="_blank" rel="noopener">Create live thread</a>
<button id="iphone-help" type="button">Help / Install</button>
<button id="iphone-terms" type="button">Terms</button>
<button id="iphone-update" type="button" hidden>Update ready</button>
</div>'''
    share = '''<div data-ios-only class="iphone-file-share">
<button id="iphone-share-html" type="button">Share HTML file</button>
<p>Choose Mail, Messages, AirDrop or another compatible app. Nothing sends automatically.</p>
</div>'''
    ready = '''<section data-ios-only id="iphone-file-ready" hidden aria-label="Prepared file">
<p id="iphone-file-name"></p><button id="iphone-share-ready" type="button">Share prepared file</button>
<a id="iphone-download" class="file-button" download>Download file</a>
<p>On iPhone, choose Save to Files in the share sheet. Keep the newest HTML copy.</p>
</section>'''
    gate = '''<dialog data-ios-only id="iphone-agreement" aria-labelledby="iphone-agreement-title">
<h2 id="iphone-agreement-title">License agreement</h2>
<div id="iphone-agreement-text" tabindex="0" role="region" aria-label="Read the agreement"></div>
<p id="iphone-agreement-hint">Scroll to the end to reveal Agree.</p>
<div class="iphone-dialog-actions"><button id="iphone-disagree" type="button">Disagree</button>
<button id="iphone-agree" type="button" hidden>Agree</button></div>
</dialog>
<dialog data-ios-only id="iphone-help-dialog" aria-labelledby="iphone-help-title">
<h2 id="iphone-help-title">Your pocket outernet</h2>
<div class="iphone-help-content">
<h3>Install on iPhone / iPad</h3><p>Open the hosted HTTPS address in Safari. Tap Share (or More → Share), then Add to Home Screen. Turn on Open as Web App if offered, then Add. Open the new icon before you start a thread.</p>
<h3>Create a live thread</h3><p>Tap Create live thread to open the online editor. Enter a title and an opening post, then share the link. Use the same browser to manage your live posts. Your offline draft stays in this editor.</p>
<h3>Post &amp; reply</h3><p>Write text, choose an optional photo, then tap Post to thread. Tap Reply under any post. Use Edit to change your own copy. Thread details changes the page title and banner.</p>
<h3>Open a thread</h3><p>Save a received HTML attachment to Files. Tap Open HTML here and choose it. Only its thread data is read; its scripts do not run. Files and photos stay on your device.</p>
<h3>Save &amp; share</h3><p>Save HTML prepares a complete file. Tap Share prepared file → Save to Files, or Download file. Share HTML file opens the phone's share sheet when it supports HTML. Choose a recipient yourself. If HTML sharing is unavailable, download and attach the file in your messaging app.</p>
<p>Email prepares an .eml draft with the HTML attached, with smaller images when necessary. Some iPhone mail apps cannot open .eml drafts; sharing the HTML directly to Mail is usually simpler. Check the attachment before sending.</p>
<h3>Offline &amp; recovery</h3><p>Wait for Ready offline while online, then this installed app can reopen without a connection. A working draft is kept in this browser, including unfinished text and pictures. Browser storage can be cleared by you or the operating system: export important threads to Files. A local draft is not a saved HTML file.</p>
<h3>Copies travel; they do not sync</h3><p>Send the newest HTML after replying. Other people's copies and a hosted page do not update automatically. An attachment preview may disable scripts; open the installed app and import the file instead.</p>
<h3>Privacy &amp; source</h3><p>No accounts, analytics, content uploads or remote thread database are built into this editor. Hosting serves the app files and may keep ordinary request logs. GPLv3-or-later; the license and readable editor travel inside every HTML export.</p>
</div><button id="iphone-help-close" type="button">Back to thread</button></dialog>
<div data-ios-only id="iphone-locked" hidden><h1>dλsociate</h1><p>Agreement declined. The editor is locked.</p><button id="iphone-review" type="button">Review agreements</button></div>'''
    replacements = {
        '<html lang="en">': '<html lang="en" data-ios>',
        '<meta charset="utf-8">': '<meta charset="utf-8">' + metadata,
        'content="width=device-width, initial-scale=1"': 'content="width=device-width, initial-scale=1, viewport-fit=cover"',
        '<p class="eyebrow">': brand + '<p class="eyebrow">',
        '<div class="browser-tools">': controls + '<div class="browser-tools">',
        '<button id="share-email"': share + '<button id="share-email"',
        '<div id="thread">': ready + '<div id="thread">',
    }
    for anchor, replacement in replacements.items():
        if document.count(anchor) != 1:
            raise ValueError(f"Shared editor markup changed around {anchor!r}")
        document = document.replace(anchor, replacement, 1)
    before, marker, runtime = document.rpartition("<script>")
    if not marker:
        raise ValueError("Shared editor runtime missing")
    config = json.dumps({"version": VERSION, "termsVersion": terms_version,
                         "karmic": KARMIC_LAW + "\n\n" + KARMIC_SIGNOFF})
    document = before + gate + '<script data-ios-only id="iphone-config" type="application/json">' + config + '</script>\n<script data-ios-only src="./iphone.js"></script>\n' + marker + runtime
    (destination / "index.html").write_text(document, encoding="utf-8", newline="\n")
    for name in ("iphone.js", "iphone.css"):
        shutil.copyfile(HERE / name, destination / name)
    shutil.copyfile(shared / "LICENSE", destination / "LICENSE")
    for size in (180, 192, 512):
        with Image.open(shared / "assets" / "dysociate.png") as icon:
            icon.convert("RGB").resize((size, size), Image.Resampling.LANCZOS).save(destination / f"icon-{size}.png")
    manifest = {"id": "./", "name": "dλsociate", "short_name": "dλsociate",
                "description": "Offline HTML threads. Your device is the server.",
                "start_url": "./", "scope": "./", "display": "standalone",
                "background_color": "#0c0714", "theme_color": "#0c0714", "lang": "en",
                "icons": [{"src": f"./icon-{s}.png", "sizes": f"{s}x{s}", "type": "image/png", "purpose": "any"} for s in (192, 512)]}
    (destination / "manifest.webmanifest").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    # Content-based cache version: editing CSS/JS must also invalidate the shell.
    digest = hashlib.sha256()
    names = ["index.html", "iphone.js", "iphone.css", "manifest.webmanifest", "LICENSE", "icon-180.png", "icon-192.png", "icon-512.png"]
    for name in names:
        digest.update((destination / name).read_bytes())
    worker = (HERE / "sw.js").read_text(encoding="utf-8").replace("__SHELL_HASH__", digest.hexdigest()[:16])
    (destination / "sw.js").write_text(worker, encoding="utf-8", newline="\n")
    print(f"Built {VERSION}: {destination.resolve()}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--shared", type=Path, default=HERE / "shared" if (HERE / "shared").is_dir() else HERE.parent / "python_pagebuilder")
    parser.add_argument("--destination", type=Path, default=HERE / "dist")
    parser.add_argument("--live-editor", default="https://dysociate.org/t/new")
    options = parser.parse_args()
    build(options.shared, options.destination, options.live_editor)
