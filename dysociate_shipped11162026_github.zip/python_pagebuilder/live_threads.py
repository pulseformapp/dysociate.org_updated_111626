"""Versioned live-thread API and per-installation ownership.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""

import ctypes
import hashlib
import hmac
import http.client
import json
import os
import re
import sqlite3
import uuid
from contextlib import contextmanager
from ctypes import wintypes
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit


PRODUCTION = 'https://dysociate.org'
LOCAL = 'http://127.0.0.1:8795'
PILOT = 'https://dysociate-live-pilot.pulseform.workers.dev'
TOKEN = re.compile(r'[A-Za-z0-9_-]{43}')
POST = re.compile(r'p_[A-Za-z0-9_-]{22}')
JOIN_REQUEST = re.compile(r'[A-Za-z0-9_-]{22}')
INVITE_PATH = re.compile(r'/t/(?:l-)?[a-z0-9]{1,12}\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}')


def live_viewer_url(text, *, allow_local=False):
    """Accept only a guest invite for an explicitly supported live service."""
    link = text.strip()
    origins = (PRODUCTION, PILOT, LOCAL) if allow_local else (PRODUCTION, PILOT)
    if not any(link.startswith(origin) and INVITE_PATH.fullmatch(link[len(origin):]) for origin in origins):
        raise ValueError('Paste a full dλsociate live thread link.')
    return link


@dataclass(frozen=True)
class LiveThread:
    title: str
    link: str
    post_id: str
    deleted: bool = False

    @property
    def locked(self):
        return urlsplit(self.link).path.startswith('/t/l-')


class _DataBlob(ctypes.Structure):
    _fields_ = [('size', wintypes.DWORD), ('data', ctypes.c_void_p)]


def _credential_blob(data, protect):
    """Use Windows DPAPI in the current user's context without a prompt."""
    buffer = ctypes.create_string_buffer(data)
    source = _DataBlob(len(data), ctypes.addressof(buffer))
    result = _DataBlob()
    if os.name != 'nt':
        raise ValueError('Windows credential protection is unavailable.')
    crypt = ctypes.WinDLL('crypt32')
    operation = crypt.CryptProtectData if protect else crypt.CryptUnprotectData
    operation.argtypes = [ctypes.POINTER(_DataBlob), ctypes.c_void_p, ctypes.c_void_p,
                          ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(_DataBlob)]
    operation.restype = wintypes.BOOL
    if not operation(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(result)):
        raise ValueError('Could not access this Windows user’s live thread credential.')
    free = ctypes.WinDLL('kernel32').LocalFree
    free.argtypes = [ctypes.c_void_p]
    free.restype = ctypes.c_void_p
    try:
        return ctypes.string_at(result.data, result.size)
    finally:
        free(result.data)


class LiveThreads:
    def __init__(self, origin=PRODUCTION, database=None):
        if origin not in (PRODUCTION, LOCAL, PILOT):
            raise ValueError('Unknown live service.')
        self.origin = origin
        self.database = Path(database) if database else (
            Path(os.environ.get('LOCALAPPDATA') or Path.home()) / 'dysociate' / 'live.sqlite3'
        )
        self.database.parent.mkdir(parents=True, exist_ok=True)
        with self._db() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS credentials (origin TEXT PRIMARY KEY, token BLOB NOT NULL);
                CREATE TABLE IF NOT EXISTS pending (
                    origin TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL,
                    operation TEXT NOT NULL, UNIQUE(origin, title, body)
                );
                CREATE TABLE IF NOT EXISTS threads (
                    origin TEXT NOT NULL, title TEXT NOT NULL, link TEXT NOT NULL,
                    post_id TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0, UNIQUE(origin, link)
                );
                CREATE TABLE IF NOT EXISTS pending_media (
                    origin TEXT NOT NULL, signature TEXT NOT NULL, operation TEXT NOT NULL,
                    UNIQUE(origin, signature)
                );
            """)

    @contextmanager
    def _db(self):
        connection = sqlite3.connect(self.database)
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def draft(self):
        with self._db() as db:
            return db.execute(
                'SELECT title, body FROM pending WHERE origin=? ORDER BY rowid DESC LIMIT 1',
                (self.origin,),
            ).fetchone() or ('', '')

    def threads(self):
        with self._db() as db:
            return [LiveThread(*row) for row in db.execute(
                'SELECT title, link, post_id, deleted FROM threads WHERE origin=? ORDER BY rowid DESC',
                (self.origin,),
            )]

    def _request(self, method, path, token=None, payload=None, media=None):
        url = urlsplit(self.origin)
        connect = http.client.HTTPSConnection if url.scheme == 'https' else http.client.HTTPConnection
        connection = connect(url.hostname, url.port, timeout=45 if media else 10)
        headers = {'Accept': 'application/json'}
        if token:
            headers['Authorization'] = 'Bearer ' + token
        data = None
        if payload is not None:
            headers['Content-Type'] = 'application/json; charset=utf-8'
            data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        if media:
            mime, attachment = media
            boundary = uuid.uuid4().hex
            headers['Content-Type'] = 'multipart/form-data; boundary=' + boundary
            data = (f'--{boundary}\r\nContent-Disposition: form-data; name="payload"\r\n\r\n'.encode() + data +
                    f'\r\n--{boundary}\r\nContent-Disposition: form-data; name="media"; filename="attachment"\r\n'
                    f'Content-Type: {mime}\r\n\r\n'.encode() + attachment + f'\r\n--{boundary}--\r\n'.encode())
        try:
            # The fixed origin and explicit HTTP calls keep credentials out of redirects.
            connection.request(method, '/api/v1' + path, data, headers)
            response = connection.getresponse()
            status = response.status
            raw = response.read(32_769)
        except (OSError, http.client.HTTPException):
            raise ValueError('Could not reach the live service. Check your connection and try again.') from None
        finally:
            connection.close()

        try:
            result = json.loads(raw) if len(raw) <= 32_768 else None
        except (ValueError, UnicodeError):
            result = None
        if status in (200, 201) and isinstance(result, dict):
            return result
        if isinstance(result, dict) and isinstance(result.get('error'), dict):
            message = result['error'].get('message')
            if isinstance(message, str) and message:
                raise ValueError(message)
        raise ValueError('The live service returned an unexpected response. Try again.')

    def _credential(self, create=False):
        with self._db() as db:
            row = db.execute('SELECT token FROM credentials WHERE origin=?', (self.origin,)).fetchone()
        if row:
            if not isinstance(row[0], bytes):
                raise ValueError('The saved live credential is invalid.')
            return _credential_blob(row[0], protect=False).decode('ascii')
        if not create:
            raise ValueError('This installation no longer has the credential for this thread.')
        token = self._request('POST', '/session', payload={'client': 'native'}).get('credential')
        if not isinstance(token, str) or not TOKEN.fullmatch(token):
            raise ValueError('The live service returned an invalid credential.')
        # If two windows ask for a credential together, both use the one that
        # was written first. Persist it before sending any content.
        protected = _credential_blob(token.encode('ascii'), protect=True)
        with self._db() as db:
            db.execute('INSERT OR IGNORE INTO credentials VALUES (?, ?)', (self.origin, protected))
        return self._credential()

    def _invite(self, link):
        path = link.removeprefix(self.origin)
        if not link.startswith(self.origin) or not INVITE_PATH.fullmatch(path):
            raise ValueError('The live service returned an invalid link.')
        return path.removeprefix('/t/')

    def create(self, title, body, media=None, *, locked=False, passkey=''):
        title, body = title.strip(), body.strip()
        if not title or len(title) > 120:
            raise ValueError('Enter a title of 1 to 120 characters.')
        if (not body and not media) or len(body.encode('utf-8')) > 4096:
            raise ValueError('Enter an opening post of up to 4,096 UTF-8 bytes.')
        passkey = passkey.strip() if locked else ''
        if passkey and (len(passkey) < 8 or len(passkey.encode('utf-8')) > 128):
            raise ValueError('Use at least 8 characters and at most 128 UTF-8 bytes for the passkey.')
        token = self._credential(create=True)
        signature = None
        if media:
            mime, attachment = media
            limits = {'image/jpeg': 1024 * 1024, 'image/png': 1024 * 1024, 'video/mp4': 4 * 1024 * 1024}
            if mime not in limits or not 0 < len(attachment) <= limits[mime]:
                raise ValueError('Photos can be up to 1 MiB and reels up to 4 MiB.')
            signature = json.dumps([title, body, mime, hashlib.sha256(attachment).hexdigest()])
        if locked:
            fingerprint = hmac.digest(token.encode('ascii'), passkey.encode('utf-8'), 'sha256').hex()
            signature = json.dumps(['locked', signature, title, body, fingerprint])
        with self._db() as db:
            if signature:
                db.execute('INSERT OR IGNORE INTO pending_media VALUES (?, ?, ?)', (self.origin, signature, uuid.uuid4().hex))
                operation, = db.execute('SELECT operation FROM pending_media WHERE origin=? AND signature=?',
                                        (self.origin, signature)).fetchone()
            else:
                db.execute('INSERT OR IGNORE INTO pending VALUES (?, ?, ?, ?)',
                           (self.origin, title, body, uuid.uuid4().hex))
                operation, = db.execute('SELECT operation FROM pending WHERE origin=? AND title=? AND body=?',
                                        (self.origin, title, body)).fetchone()
        # The receipt may be committed on the server even if the response is
        # lost. Reuse the stored operation ID when the same draft is submitted.
        payload = {
            'operationId': operation, 'title': title, 'openingPost': {'body': body},
        }
        if locked:
            payload['accessMode'] = 'locked'
        if passkey:
            payload['passkey'] = passkey
        result = self._request('POST', '/threads', token, payload, media)
        link, post = result.get('shareUrl'), result.get('post')
        if not isinstance(link, str) or not isinstance(post, dict) or not POST.fullmatch(str(post.get('id'))):
            raise ValueError('The live service returned an invalid thread.')
        self._invite(link)
        deleted = post.get('deletedAt') is not None
        with self._db() as db:
            db.execute('INSERT OR IGNORE INTO threads VALUES (?, ?, ?, ?, ?)',
                       (self.origin, title, link, post['id'], deleted))
            db.execute('DELETE FROM pending WHERE origin=? AND operation=?', (self.origin, operation))
            if signature:
                db.execute('DELETE FROM pending_media WHERE origin=? AND operation=?', (self.origin, operation))
        return LiveThread(title, link, post['id'], deleted)

    def creator_link(self, thread):
        invite = self._invite(thread.link)
        result = self._request('POST', f'/threads/{invite}/handoff', self._credential(), {})
        link = result.get('creatorUrl', '')
        if not isinstance(link, str) or not re.fullmatch(re.escape(thread.link) + r'#creator=[A-Za-z0-9_-]{43}', link):
            raise ValueError('The live service returned an invalid creator link.')
        return link

    def join_requests(self, thread, request_id=None, *, approve=False):
        invite = self._invite(thread.link)
        route = f'/threads/{invite}/requests'
        token = self._credential()
        if request_id is None:
            result = self._request('GET', route, token)
        else:
            if not JOIN_REQUEST.fullmatch(request_id):
                raise ValueError('The join request is invalid.')
            result = self._request('POST', f'{route}/{request_id}', token,
                                   {'decision': 'approved' if approve else 'declined'})
        requests = result.get('requests')
        if not isinstance(requests, list) or not all(
            isinstance(row, dict) and isinstance(row.get('id'), str) and JOIN_REQUEST.fullmatch(row['id'])
            and isinstance(row.get('name'), str) and isinstance(row.get('requestedAt'), str)
            for row in requests
        ):
            raise ValueError('The live service returned an invalid join request list.')
        return requests

    def delete_opening_post(self, thread):
        invite = self._invite(thread.link)
        if not POST.fullmatch(thread.post_id):
            raise ValueError('The opening post ID is invalid.')
        result = self._request('DELETE', f'/threads/{invite}/posts/{thread.post_id}', self._credential())
        post = result.get('post')
        if not isinstance(post, dict) or post.get('id') != thread.post_id or not post.get('deletedAt'):
            raise ValueError('The live service did not confirm deletion. Try again.')
        with self._db() as db:
            db.execute('UPDATE threads SET deleted=1 WHERE origin=? AND link=?', (self.origin, thread.link))
