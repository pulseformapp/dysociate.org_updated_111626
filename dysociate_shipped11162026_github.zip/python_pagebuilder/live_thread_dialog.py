"""Windows editor controls for creating and managing live threads.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""

import io
import sqlite3
import tkinter as tk
import webbrowser
from queue import SimpleQueue
from threading import Thread
from tkinter import filedialog, messagebox, ttk

from PIL import Image, ImageOps, ImageTk
from live_threads import LOCAL, PILOT
from native_composer import OptionsDraft, compose_thread, show_thread_link
from ui_theme import BLACK, FIELD, FONT, ACCENT, TEXT


def show_live_threads(app, client):
    pending_title, pending_body = client.draft()
    notice = 'Anyone with the link can read and reply.'
    if client.origin == LOCAL:
        notice = 'Local test on this PC. ' + notice
    if client.origin == PILOT:
        notice = 'HTTPS pilot. Use test content. ' + notice

    def copy_address(address):
        app.clipboard_clear()
        app.clipboard_append(address)

    initial_status = 'Retry the saved draft to recover its link.' if pending_body else ''
    new_thread = None
    if app.native_ui:
        try:
            message = notice + ('\n' + initial_status if initial_status else '')
            result = compose_thread(app, pending_title, pending_body, message, client.create)
        except (OSError, AttributeError):
            initial_status = 'The C++ preview is unavailable on this display. You can create the thread here.'
        else:
            if result is None:
                return
            if isinstance(result, OptionsDraft):
                pending_title, pending_body = result.title, result.body
            else:
                new_thread = result
                try:
                    if not show_thread_link(app, result, app.open_live_thread, copy_address):
                        return
                except (OSError, AttributeError):
                    pass  # The successfully saved link can still be shown below.
                pending_title, pending_body = '', ''
                initial_status = 'Live thread ready. Open it or copy the link.'

    dialog = tk.Toplevel(app)
    dialog.title('Create live thread · dλsociate')
    dialog.configure(bg=BLACK, padx=22, pady=18)
    dialog.transient(app)
    dialog.grab_set()
    app.label(dialog, notice, fg=ACCENT, wraplength=490, justify='left').pack(anchor='w')
    app.label(dialog, 'Thread title').pack(anchor='w', pady=(12, 3))
    title = tk.StringVar(value=pending_title)
    title_input = app.entry(dialog, title)
    title_input.pack(fill='x')
    app.label(dialog, 'Opening post').pack(anchor='w', pady=(10, 3))
    body = tk.Text(dialog, height=5, width=48, wrap='word', bg=FIELD, fg=TEXT, insertbackground=TEXT,
                   font=(FONT, 11), padx=8, pady=6, relief='flat')
    body.insert('1.0', pending_body)
    body.pack(fill='x')
    locked = tk.BooleanVar()
    passkey = tk.StringVar()
    access_row = tk.Frame(dialog, bg=BLACK)
    passkey_row = tk.Frame(dialog, bg=BLACK)
    app.label(passkey_row, 'Passkey (optional)').pack(anchor='w')
    passkey_input = app.entry(passkey_row, passkey)
    passkey_input.configure(show='*')
    passkey_input.pack(fill='x')

    def update_access():
        if locked.get():
            passkey_row.pack(fill='x', after=access_row)
        else:
            passkey_row.pack_forget()

    lock_choice = tk.Checkbutton(access_row, text='Locked · guests ask to join', variable=locked,
        command=update_access, bg=BLACK, fg=TEXT, selectcolor=FIELD, activebackground=BLACK, activeforeground=ACCENT)
    lock_choice.pack(anchor='w')
    if client.origin in (LOCAL, PILOT):
        access_row.pack(fill='x', pady=(7, 0))
    status = tk.StringVar(value=initial_status)

    media_row = tk.Frame(dialog, bg=BLACK)
    media = None
    preview = app.label(dialog, '')
    if client.origin in (LOCAL, PILOT):
        media_row.pack(fill='x', pady=(7, 0))
    photo_button = app.button(media_row, 'Add photo', lambda: choose_photo())
    record_button = app.button(media_row, 'Record reel', lambda: app.record_reel(dialog, use_reel))
    remove_button = app.button(media_row, 'Remove attachment', lambda: set_media(None))
    for button in (photo_button, record_button, remove_button):
        button.pack(side='left', padx=(0, 6))

    controls = tk.Frame(dialog, bg=BLACK)
    controls.pack(fill='x', pady=(8, 12))
    create_button = app.button(controls, 'Create live thread', lambda: create(), primary=True)
    create_button.pack(side='left')
    close_button = app.button(controls, 'Close', lambda: close(), subtle=True)
    close_button.pack(side='right')

    app.label(dialog, 'Your live threads').pack(anchor='w', pady=(0, 3))
    history = ttk.Combobox(dialog, state='readonly', width=50)
    history.pack(fill='x')
    link = tk.StringVar()
    link_input = app.entry(dialog, link)
    link_input.configure(state='readonly', readonlybackground=FIELD)
    link_input.pack(fill='x', pady=5)
    actions = tk.Frame(dialog, bg=BLACK)
    actions.pack(fill='x')
    open_button = app.button(actions, 'Open link', lambda: open_link())
    share_button = app.button(actions, 'Copy link', lambda: copy_link())
    delete_button = app.button(actions, 'Delete opening post', lambda: delete_post(), danger=True)
    for button in (open_button, share_button, delete_button):
        button.pack(side='left', padx=(0, 5))
    request_panel = tk.Frame(dialog, bg=BLACK)
    app.label(request_panel, 'Join requests', fg=ACCENT).pack(anchor='w')
    requests = ttk.Treeview(request_panel, columns=('name', 'time'), show='headings',
                            selectmode='browse', height=4)
    requests.heading('name', text='Guest')
    requests.heading('time', text='Requested (UTC)')
    requests.column('name', width=225)
    requests.column('time', width=160)
    requests.pack(fill='x')
    request_actions = tk.Frame(request_panel, bg=BLACK)
    request_actions.pack(fill='x', pady=5)
    approve_button = app.button(request_actions, 'Approve', lambda: decide(True), primary=True)
    decline_button = app.button(request_actions, 'Decline', lambda: decide(False))
    reload_button = app.button(request_actions, 'Refresh', lambda: open_link())
    browser_button = app.button(request_actions, 'Open creator view', lambda: open_creator())
    for button in (approve_button, decline_button, reload_button, browser_button):
        button.pack(side='left', padx=(0, 5))
    app.label(dialog, textvariable=status, wraplength=490, justify='left').pack(fill='x', pady=(8, 0))
    rows = []
    busy = False

    def current():
        return rows[history.current()] if 0 <= history.current() < len(rows) else None

    def update_buttons():
        item = current()
        link.set(item.link if item else '')
        for control in (title_input, body, create_button, close_button, photo_button, record_button, remove_button,
                        lock_choice, passkey_input):
            control.configure(state='disabled' if busy else 'normal')
        history.configure(state='disabled' if busy or not rows else 'readonly')
        for button in (open_button, share_button):
            button.configure(state='normal' if item and not busy else 'disabled')
        open_button.configure(text='Manage requests' if item and item.locked else 'Open link')
        delete_button.configure(state='normal' if item and not item.deleted and not busy else 'disabled')
        for button in (approve_button, decline_button):
            button.configure(state='normal' if requests.selection() and not busy else 'disabled')
        for button in (reload_button, browser_button):
            button.configure(state='normal' if item and item.locked and not busy else 'disabled')

    def refresh(select=None):
        rows[:] = client.threads()
        history.configure(values=[f'{index + 1}. {item.title}' + (' · Locked' if item.locked else '') +
                                  (' (opening post deleted)' if item.deleted else '')
                                  for index, item in enumerate(rows)])
        if rows:
            history.current(next((index for index, item in enumerate(rows) if item.link == select), 0))
        else:
            history.set('No live threads yet')
        request_panel.pack_forget()
        update_buttons()

    def close():
        if not busy:
            dialog.destroy()

    def perform(progress, work, complete):
        nonlocal busy
        if busy:
            return
        queue = SimpleQueue()
        busy = True
        update_buttons()
        status.set(progress)

        def run():
            try:
                queue.put((True, work()))
            except (ValueError, OSError, sqlite3.Error) as error:
                queue.put((False, str(error)))

        def poll():
            nonlocal busy
            if queue.empty():
                dialog.after(60, poll)
                return
            success, result = queue.get()
            busy = False
            update_buttons()
            if success:
                complete(result)
            else:
                status.set(result)

        Thread(target=run, daemon=True).start()
        dialog.after(60, poll)

    def create_request():
        requires_approval, code = locked.get(), passkey.get()
        selected = media

        def submit(thread_title, opening):
            return client.create(thread_title, opening, selected, locked=requires_approval, passkey=code)
        return submit

    def created(item):
        title.set('')
        body.delete('1.0', 'end')
        passkey.set('')
        locked.set(False)
        update_access()
        set_media(None)
        refresh(item.link)
        status.set('Locked thread ready. Open Manage requests or copy the guest link.' if item.locked else
                   'Live thread ready. Open it or copy the link.')

    def create():
        thread_title, opening = title.get(), body.get('1.0', 'end-1c')
        submit = create_request()
        perform('Creating live thread…', lambda: submit(thread_title, opening), created)

    def set_media(value, image=None):
        nonlocal media
        media = value
        preview.image = ImageTk.PhotoImage(image, master=dialog) if image else None
        preview.configure(image=preview.image or '')
        if image:
            preview.pack(anchor='w', before=controls)
        else:
            preview.pack_forget()
        status.set('Reel ready to post.' if value and value[0] == 'video/mp4' else '')

    def choose_photo():
        path = filedialog.askopenfilename(parent=dialog, title='Add photo', filetypes=[('JPEG or PNG', '*.jpg *.jpeg *.png')])
        if not path:
            return
        try:
            with Image.open(path) as original:
                if original.format not in ('JPEG', 'PNG') or original.width * original.height > 40_000_000:
                    raise ValueError('Choose a JPEG or PNG photo up to 40 megapixels.')
                photo = ImageOps.exif_transpose(original).convert('RGB')
            photo.thumbnail((1400, 1400))
            buffer = io.BytesIO()
            photo.save(buffer, format='JPEG', quality=85)
            photo.thumbnail((120, 76))
            set_media(('image/jpeg', buffer.getvalue()), photo)
        except (OSError, ValueError, Image.DecompressionBombError) as problem:
            status.set(str(problem))

    def use_reel(clip):
        set_media(('video/mp4', clip))

    def copy_link():
        copy_address(link.get())
        status.set('Link copied. Paste it into any message.')

    def open_link():
        item = current()
        if item and item.locked:
            perform('Loading join requests…', lambda: client.join_requests(item), show_requests)
        elif item:
            app.open_live_thread(item.link)

    def show_requests(items):
        requests.delete(*requests.get_children())
        for item in items:
            requested = item['requestedAt'].replace('T', ' ').rstrip('Z').split('.')[0]
            requests.insert('', 'end', iid=item['id'], values=(item['name'], requested))
        request_panel.pack(fill='x', after=actions, pady=(8, 0))
        status.set(f'{len(items)} pending request' + ('' if len(items) == 1 else 's') if items else
                   'No pending requests. Use Refresh after a guest requests to join.')
        update_buttons()

    def decide(approve):
        selected = requests.selection()
        if not selected:
            return
        item, request_id = current(), selected[0]

        def finished(items):
            show_requests(items)
            status.set('Guest approved. Their waiting page will open shortly.' if approve else 'Request declined.')

        perform('Saving decision…', lambda: client.join_requests(item, request_id, approve=approve), finished)

    def open_creator():
        item = current()
        if item:
            perform('Opening creator view…', lambda: client.creator_link(item),
                    lambda address: status.set('Creator view opened.' if webbrowser.open(address) else
                                               'Could not open the browser. Try again.'))

    def delete_post():
        item = current()
        if item and messagebox.askyesno('Delete opening post', 'Delete your opening post? Replies stay in the thread.',
                                        parent=dialog):
            def finished(_result):
                refresh(item.link)
                status.set('Opening post deleted. The link and replies are still available.')

            perform('Deleting opening post…', lambda: client.delete_opening_post(item), finished)

    def select_thread(_event):
        request_panel.pack_forget()
        requests.delete(*requests.get_children())
        update_buttons()

    history.bind('<<ComboboxSelected>>', select_thread)
    requests.bind('<<TreeviewSelect>>', lambda _event: update_buttons())
    dialog.protocol('WM_DELETE_WINDOW', close)
    dialog.bind('<Escape>', lambda _event: (close(), 'break')[1])
    refresh(new_thread.link if new_thread else None)
    (open_button if new_thread else title_input).focus_set()
