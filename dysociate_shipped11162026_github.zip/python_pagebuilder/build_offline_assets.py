"""Write the portable offline HTML shell used by both live viewers.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""

from pathlib import Path
import sys

from pagebuilder_gui import Page, render_document


def build(destination):
    destination.mkdir(parents=True, exist_ok=True)
    page = render_document(Page(title="Offline thread"))
    start = page.index('type="application/json">', page.index('id="luna-page-data"'))
    start += len('type="application/json">')
    end = page.index("</script>", start)
    (destination / "offline-head.txt").write_text(page[:start], encoding="utf-8", newline="\n")
    (destination / "offline-tail.txt").write_text(page[end:], encoding="utf-8", newline="\n")
    (destination / "live-snapshot.js").write_bytes(Path(__file__).with_name("live_snapshot.js").read_bytes())


if __name__ == "__main__":
    build(Path(sys.argv[1]))
